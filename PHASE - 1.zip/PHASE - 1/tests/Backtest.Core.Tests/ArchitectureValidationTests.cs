using System.Text;
using Backtest.Core.Determinism;
using Backtest.Core.Engine;
using Backtest.Core.Events;
using Backtest.Core.Primitives;
using Backtest.Core.Time;
using Backtest.Core.Wire;
using Xunit;

namespace Backtest.Core.Tests;

/// <summary>
/// Architecture validation tests. These encode the contracts documented in
/// docs/architecture/*.md; if any of these fail, an architecture rule is broken
/// (see docs/QUALITY_GATES.md).
/// </summary>
public class ArchitectureValidationTests
{
    // ---------------------------------------------------------------- money

    [Fact]
    public void Money_round_trip_is_exact()
    {
        var m = new Money(1234.5678901m, "USD");
        Assert.Equal(1234.5678901m, m.Amount);
        Assert.Equal("USD", m.Currency);
    }

    [Fact]
    public void Money_rejects_currency_mismatch()
    {
        var usd = new Money(1m, "USD");
        var eur = new Money(1m, "EUR");
        Assert.Throws<InvalidOperationException>(() => usd + eur);
        Assert.Throws<InvalidOperationException>(() => usd - eur);
        Assert.Throws<InvalidOperationException>(() => usd > eur);
    }

    [Fact]
    public void Money_addition_and_subtraction_are_exact()
    {
        var a = new Money(0.1m, "USD");
        var b = new Money(0.2m, "USD");
        Assert.Equal(0.3m, (a + b).Amount);
        Assert.Equal(-0.1m, (a - b).Amount);
    }

    [Theory]
    [InlineData("usd", "USD")]
    [InlineData("JPY", "JPY")]
    public void Money_normalizes_currency_case(string input, string expected) =>
        Assert.Equal(expected, new Money(1m, input).Currency);

    [Theory]
    [InlineData("")]
    [InlineData("US")]
    [InlineData("USDD")]
    [InlineData("US1")]
    public void Money_rejects_invalid_currency_codes(string currency) =>
        Assert.ThrowsAny<ArgumentException>(() => new Money(1m, currency));

    [Fact]
    public void Money_rounds_to_minor_units_only_on_request()
    {
        var m = new Money(10.005m, "USD");
        Assert.Equal(10.005m, m.Amount); // internal precision preserved
        Assert.Equal(10.01m, m.RoundToMinorUnits(RoundingRule.HalfAwayFromZero).Amount);
        Assert.Equal(10.00m, m.RoundToMinorUnits(RoundingRule.HalfEven).Amount);
    }

    // ------------------------------------------------------------- quantity

    [Fact]
    public void Quantity_rejects_negative_values() =>
        Assert.Throws<ArgumentOutOfRangeException>(() => new Quantity(-0.01m));

    [Fact]
    public void Quantity_conforms_down_to_step()
    {
        var q = new Quantity(0.179m).ConformToStep(0.01m);
        Assert.Equal(0.17m, q.Value);
    }

    [Fact]
    public void Quantity_underflow_is_rejected()
    {
        var q = new Quantity(0.05m);
        Assert.Throws<InvalidOperationException>(() => q - new Quantity(0.1m));
    }

    // ---------------------------------------------------------------- price

    [Fact]
    public void Price_rejects_non_positive_values()
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => new Price(0m));
        Assert.Throws<ArgumentOutOfRangeException>(() => new Price(-1m));
    }

    [Fact]
    public void Price_conforms_to_tick_with_half_away_from_zero()
    {
        Assert.Equal(1.10395m, new Price(1.103947m).ConformToTick(0.00001m).Value);
        Assert.Equal(1.10394m, new Price(1.103944m).ConformToTick(0.00001m).Value);
        Assert.Equal(1.10395m, new Price(1.103949m).ConformToTick(0.00001m).Value);
    }

    // ----------------------------------------------------------------- time

    [Fact]
    public void Clock_is_strictly_monotonic()
    {
        var clock = new SimClock(DateTimeOffset.Parse("2024-01-02T00:00:00Z"));
        clock.AdvanceTo(DateTimeOffset.Parse("2024-01-02T00:00:01Z"));
        Assert.Throws<InvalidOperationException>(
            () => clock.AdvanceTo(DateTimeOffset.Parse("2024-01-02T00:00:00Z")));
    }

    [Fact]
    public void Clock_keeps_subsequence_for_equal_timestamps()
    {
        var clock = new SimClock(DateTimeOffset.Parse("2024-01-02T00:00:00Z"));
        var before = clock.SubSequence;
        clock.AdvanceTo(clock.CurrentUtc);
        Assert.Equal(before + 1, clock.SubSequence);
    }

    [Fact]
    public void Clock_normalizes_to_utc()
    {
        var clock = new SimClock(new DateTimeOffset(2024, 1, 2, 3, 0, 0, TimeSpan.FromHours(5)));
        Assert.Equal(TimeSpan.Zero, clock.CurrentUtc.Offset);
    }

    // --------------------------------------------------------------- events

    [Fact]
    public void Envelope_requires_utc_timestamp()
    {
        var clock = new SimClock(DateTimeOffset.UtcNow);
        var envelope = EventEnvelope.Create(
            EventSource.MarketData, new MarketTick("EURUSD", 1, 1.00001m), clock, allocator: 1);
        Assert.Equal(TimeSpan.Zero, envelope.TimestampUtc.Offset);
        Assert.Equal(1, envelope.EventId);
        Assert.Equal(1, envelope.SequenceNumber);
    }

    [Fact]
    public void Queue_orders_by_time_then_rank_then_sequence()
    {
        var clock = new SimClock(DateTimeOffset.Parse("2024-01-02T00:00:00Z"));
        var t0 = clock.CurrentUtc;
        var later = t0.AddMinutes(1);

        var seq = 1L;
        EventEnvelope Make(EventSource src, IEventPayload payload, DateTimeOffset ts) =>
            EventEnvelope.Create(src, payload, new SimClock(ts), seq++);

        // Insert deliberately out of order.
        var queue = new EventQueue();
        queue.Push(Make(EventSource.Strategy, new StrategySignal("s", "n", 0.5m), t0));
        queue.Push(Make(EventSource.Clock, new TimerEvent("t"), t0));
        queue.Push(Make(EventSource.MarketData, new MarketTick("EURUSD", 1, 1.00001m), later));
        queue.Push(Make(EventSource.MarketData, new MarketTick("EURUSD", 1, 1.00001m), t0));

        Assert.Equal(
            new[] { EventKind.MarketTick, EventKind.TimerEvent, EventKind.StrategySignal, EventKind.MarketTick },
            new[] { queue.Pop(), queue.Pop(), queue.Pop(), queue.Pop() }.Select(e => e.Payload.Kind));
    }

    [Fact]
    public void Queue_is_insertion_order_independent()
    {
        var clock = new SimClock(DateTimeOffset.Parse("2024-01-02T00:00:00Z"));
        var t0 = clock.CurrentUtc;
        var seq = 1L;
        EventEnvelope Make(EventSource src, IEventPayload payload) =>
            EventEnvelope.Create(src, payload, new SimClock(t0), seq++);

        var forward = new EventQueue();
        forward.Push(Make(EventSource.MarketData, new MarketTick("EURUSD", 1, 1.00001m)));
        forward.Push(Make(EventSource.Clock, new TimerEvent("t")));
        forward.Push(Make(EventSource.Strategy, new StrategySignal("s", "n", 0.5m)));

        var backward = new EventQueue();
        backward.Push(Make(EventSource.Strategy, new StrategySignal("s", "n", 0.5m)));
        backward.Push(Make(EventSource.Clock, new TimerEvent("t")));
        backward.Push(Make(EventSource.MarketData, new MarketTick("EURUSD", 1, 1.00001m)));

        var f = new[] { forward.Pop(), forward.Pop(), forward.Pop() }.Select(e => e.Payload.Kind).ToArray();
        var b = new[] { backward.Pop(), backward.Pop(), backward.Pop() }.Select(e => e.Payload.Kind).ToArray();
        Assert.Equal(f, b);
    }

    // --------------------------------------------------------------- kernel

    [Fact]
    public void Kernel_trace_is_deterministic_across_instances()
    {
        var start = DateTimeOffset.Parse("2024-01-02T00:00:00Z");

        static SimulationKernel Build(DateTimeOffset start)
        {
            var k = new SimulationKernel(start, randomSeed: 42);
            k.Schedule(EventSource.MarketData, new MarketTick("EURUSD", 1.10394m, 1.10402m), start);
            k.Schedule(EventSource.MarketData, new MarketTick("EURUSD", 1.10395m, 1.10403m), start.AddSeconds(1));
            k.Schedule(EventSource.Clock, new TimerEvent("t1"), start.AddSeconds(2));
            k.Schedule(EventSource.MarketData, new MarketTick("EURUSD", 1.10393m, 1.10401m), start.AddSeconds(2));
            k.Schedule(EventSource.Clock, new TimerEvent("t2"), start.AddSeconds(3));
            return k;
        }

        var a = Build(start);
        var b = Build(start);
        a.Run();
        b.Run();
        Assert.Equal(a.TraceToCanonicalJson(), b.TraceToCanonicalJson());
        Assert.Equal(5, a.Trace.Count);
    }

    [Fact]
    public void Kernel_never_advances_clock_before_processing()
    {
        var start = DateTimeOffset.Parse("2024-01-02T00:00:00Z");
        var kernel = new SimulationKernel(start);
        kernel.Schedule(EventSource.MarketData, new MarketTick("EURUSD", 1, 1.00001m), start.AddSeconds(10));
        kernel.Run();
        Assert.Equal(start.AddSeconds(10), kernel.Clock.CurrentUtc);
    }

    [Fact]
    public void Kernel_respects_simulation_deadline()
    {
        var start = DateTimeOffset.Parse("2024-01-02T00:00:00Z");
        var kernel = new SimulationKernel(start);
        kernel.Schedule(EventSource.Clock, new TimerEvent("far"), start.AddHours(1));
        kernel.Schedule(EventSource.Clock, new TimerEvent("near"), start.AddSeconds(5));
        kernel.Run(start.AddSeconds(10));
        Assert.Single(kernel.Trace);
        Assert.Equal("near", Assert.IsType<TimerEvent>(kernel.Trace[0].Payload).TimerId);
        Assert.Equal(KernelState.Completed, kernel.State);
    }

    [Fact]
    public void Kernel_rejects_stopped_reuse()
    {
        var start = DateTimeOffset.Parse("2024-01-02T00:00:00Z");
        var kernel = new SimulationKernel(start);
        kernel.Run();
        Assert.Throws<ObjectDisposedException>(() =>
            kernel.Schedule(EventSource.Clock, new TimerEvent("t"), start));
        Assert.Throws<InvalidOperationException>(() => kernel.Run());
    }

    [Fact]
    public void Kernel_allocates_monotonic_event_ids()
    {
        var start = DateTimeOffset.Parse("2024-01-02T00:00:00Z");
        var kernel = new SimulationKernel(start);
        kernel.Schedule(EventSource.Clock, new TimerEvent("a"), start);
        kernel.Schedule(EventSource.Clock, new TimerEvent("b"), start);
        kernel.Run();
        Assert.True(kernel.Trace[0].EventId < kernel.Trace[1].EventId);
    }

    // ----------------------------------------------------------------- wire

    [Fact]
    public void Wire_frame_round_trips()
    {
        var payload = new byte[] { 0x01, 0x02, 0x03 };
        var frame = WireCodec.Encode(MessageType.Initialize, 0xDEADBEEF, payload);
        var decoded = WireCodec.Decode(frame);
        Assert.Equal(MessageType.Initialize, decoded.Type);
        Assert.Equal(0xDEADBEEFUL, decoded.CorrelationId);
        Assert.Equal(payload, decoded.Payload);
        Assert.Equal(WireCodec.CurrentVersion, decoded.Version);
    }

    [Fact]
    public void Wire_length_prefix_covers_entire_frame()
    {
        var frame = WireCodec.Encode(MessageType.Ping, 1, []);
        var declared = BitConverter.ToUInt32(frame, 0);
        Assert.Equal(frame.Length, (int)declared);
        Assert.Equal(WireCodec.MinFrameLength, frame.Length);
    }

    [Theory]
    [InlineData(0, 8)]        // truncated header
    [InlineData(1, 18)]       // one byte short of minimum
    public void Wire_rejects_malformed_frames(byte filler, int length)
    {
        var bytes = new byte[length];
        Array.Fill(bytes, filler);
        var ex = Assert.Throws<WireException>(() => WireCodec.Decode(bytes));
        Assert.Equal(ErrorCode.MalformedMessage, ex.Code);
    }

    [Fact]
    public void Wire_rejects_length_prefix_mismatch()
    {
        var frame = WireCodec.Encode(MessageType.Ping, 1, [0xAA]);
        frame[0] = 0xFF; // corrupt declared length
        var ex = Assert.Throws<WireException>(() => WireCodec.Decode(frame));
        Assert.Equal(ErrorCode.MalformedMessage, ex.Code);
    }

    [Fact]
    public void Wire_params_round_trip_with_escapes()
    {
        var input = new Dictionary<string, string>
        {
            ["strategy_id"] = "demo",
            ["note"] = "line1\nline2 with \\ backslash and = equals",
            ["z_last"] = "value",
        };
        var encoded = WireParams.Encode(input);
        var decoded = WireParams.Decode(encoded);
        Assert.Equal(input.Count, decoded.Count);
        foreach (var (key, value) in input)
        {
            Assert.Equal(value, decoded[key]);
        }
    }

    [Fact]
    public void Wire_params_rejects_line_without_equals()
    {
        var ex = Assert.Throws<WireException>(() => WireParams.Decode("no-separator-here\n"u8.ToArray()));
        Assert.Equal(ErrorCode.MalformedMessage, ex.Code);
    }

    // ------------------------------------------------------------ determinism

    [Fact]
    public void Seeded_random_matches_reference_vector()
    {
        var rng = new SeededRandom(0);
        Assert.Equal(0xE220A8397B1DCDAFUL, rng.NextUInt64());
    }

    [Fact]
    public void Seeded_random_is_reproducible()
    {
        const ulong Seed = 0x123456789ABCDEFUL;
        var a = new SeededRandom(Seed);
        var b = new SeededRandom(Seed);
        for (var i = 0; i < 10_000; i++)
        {
            Assert.Equal(a.NextUInt64(), b.NextUInt64());
        }
    }

    [Fact]
    public void Seeded_random_double_is_in_unit_interval()
    {
        var rng = new SeededRandom(7);
        for (var i = 0; i < 10_000; i++)
        {
            var d = rng.NextDouble();
            Assert.InRange(d, 0.0, 1.0 - double.Epsilon);
        }
    }

    // ---------------------------------------------------- serialization format

    [Fact]
    public void Canonical_trace_format_is_frozen()
    {
        var clock = new SimClock(DateTimeOffset.Parse("2024-01-02T00:00:00Z"));
        var envelope = EventEnvelope.Create(
            EventSource.MarketData, new MarketTick("EURUSD", 1.1m, 1.10002m), clock, allocator: 1);
        Assert.Equal(
            "{\"eventId\":1,\"seq\":1,\"ts\":\"2024-01-02T00:00:00.0000000+00:00\",\"rank\":10,\"src\":\"MarketData\",\"kind\":\"MarketTick\"}",
            KernelTrace.ToCanonicalJson(envelope));
    }

    // Note: canonical-trace culture independence is guaranteed two ways:
    // 1. KernelTrace formats with CultureInfo.InvariantCulture explicitly.
    // 2. The project builds with InvariantGlobalization=true, so a machine
    //    culture cannot leak in by construction.
    // The byte-exact format itself is pinned by Canonical_trace_format_is_frozen.
}
