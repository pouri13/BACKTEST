# BACKTEST

Professional-grade Windows desktop platform for **trading simulation, market replay, algorithmic backtesting, and strategy debugging** — fully independent of MetaTrader, MT4/MT5, TradingView, and Soft4FX.

## Vision

Tick-level, event-driven backtesting with realistic broker simulation (spread, commission, swap, slippage, latency, partial fills), multi-symbol/multi-timeframe replay, deterministic and snapshotable runs, branchable "what-if" scenarios, a language-agnostic strategy API, and a professional charting UI. Soft4FX-style replay capability is the baseline, not the ceiling.

## Current phase: 0 — Architecture & Foundation ✅

Phase 0 delivers the architectural foundation, not the product. Status:

| Area | Status |
|---|---|
| Product requirements, feature matrix | ✅ complete (docs/specifications) |
| System architecture, event/time/money models, domain & API specs, ADRs | ✅ complete (docs/architecture) |
| Deterministic kernel, event queue, SimClock, exact-decimal primitives, strategy wire codec | ✅ implemented, 37 architecture tests green |
| Headless proof (CLI) | ✅ `Backtest.Cli` runs the full core with zero UI |
| Backtesting engine, broker simulator, data pipeline | ⛔ Phase 1–2 (designed, not built) |
| Charting / UI | ⛔ Phase 3 (designed, not built) |

Development status is tracked honestly per phase — see docs/phases/PHASE_0_REPORT.md and docs/QUALITY_GATES.md (no stubs pretending to be features).

## Build

Requires the .NET 8 SDK (pinned via `global.json`).

```bash
dotnet build -c Release
```

## Run the Phase 0 demo (headless core)

```bash
dotnet run --project src/Backtest.Cli -c Release -- demo
dotnet run --project src/Backtest.Cli -c Release -- selftest
```

The `demo` command schedules market/timer events, runs the deterministic kernel, and prints the canonical event trace. `selftest` runs in-process architecture smoke checks.

## Test

```bash
dotnet test -c Release
```

37 tests pin the Phase 0 contracts: deterministic event ordering, clock monotonicity, exact decimal money math, tick/step conformance, wire framing validation, seeded-RNG reproducibility, and canonical trace format.

## Repository layout

```
docs/
  specifications/     product requirements, feature matrix
  architecture/       system architecture + all model specs
    adr/              architecture decision records
  testing/            testing strategy
  phases/             per-phase reports (honest status)
  QUALITY_GATES.md    objective completion criteria
src/
  Backtest.Core/      headless domain core (no UI deps, ever)
  Backtest.Cli/       headless host / demo
tests/
  Backtest.Core.Tests/ architecture validation tests
scripts/              docs/consistency tooling
.github/workflows/    CI (Windows: build + format check + tests)
```

## Roadmap

| Phase | Scope | Status |
|---|---|---|
| 0 | Architecture, specifications, foundation code, CI | ✅ this release |
| 1 | Market-data pipeline: store, import, validation, calendars, config | planned |
| 2 | Backtest engine: broker simulator, C# strategy runtime, snapshots | planned |
| 3 | Replay engine, sandbox, Avalonia UI + charting | planned |
| 4 | Analytics, reporting, Python runtime, portfolio backtesting | planned |
| 5 | Optimization, plugins, packaging | planned |

Planned phases are designed in docs/architecture (data, performance, security, snapshot, sandbox) — nothing there is implemented yet.

## License

MIT — see LICENSE.
