using Backtest.Core.Engine;
using Backtest.Core.Events;
using Backtest.Core.Wire;

namespace Backtest.Cli;

/// <summary>
/// Phase 0 headless host. Proves the core runs without any UI (rule 7):
///   demo      — schedules market/timer events, runs the kernel, prints the trace
///   selftest  — in-process architecture smoke checks (framing, determinism)
/// No backtesting, charting or strategy runtime exists yet (see docs/phases/PHASE_0_REPORT.md).
/// </summary>
public static class Program
{
    public static int Main(string[] args)
    {
        if (args.Length == 0 || args[0] is "-h" or "--help")
        {
            Console.WriteLine("BACKTEST Phase 0 (architecture foundation — no engines yet)");
            Console.WriteLine("Usage: backtest <demo|selftest>");
            return 0;
        }

        try
        {
            return args[0] switch
            {
                "demo" => RunDemo(),
                "selftest" => RunSelfTest(),
                _ => Unknown(args[0]),
            };
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"error: {ex.Message}");
            return 1;
        }
    }

    private static int Unknown(string cmd)
    {
        Console.Error.WriteLine($"unknown command '{cmd}' — try 'demo' or 'selftest'");
        return 2;
    }

    private static int RunDemo()
    {
        var start = DateTimeOffset.Parse("2024-01-02T00:00:00Z");
        var kernel = new SimulationKernel(start, randomSeed: 42);

        kernel.Schedule(EventSource.MarketData, new MarketTick("EURUSD", 1.10394m, 1.10402m), start);
        kernel.Schedule(EventSource.MarketData, new MarketTick("EURUSD", 1.10395m, 1.10403m), start.AddSeconds(1));
        kernel.Schedule(EventSource.Clock, new TimerEvent("t1"), start.AddSeconds(2));
        kernel.Schedule(EventSource.MarketData, new MarketTick("EURUSD", 1.10393m, 1.10401m), start.AddSeconds(2));

        var completion = kernel.Run();
        Console.WriteLine($"trace ({completion.EventsProcessed} events, sim time {kernel.Clock.CurrentUtc:O}):");
        Console.WriteLine(kernel.TraceToCanonicalJson());
        return 0;
    }

    private static int RunSelfTest()
    {
        var checks = new List<(string Name, Func<bool> Check)>
        {
            ("wire frame roundtrip", CheckWireRoundtrip),
            ("wire rejects truncated frame", CheckWireRejectsTruncated),
            ("event queue deterministic order", CheckQueueOrder),
            ("money rejects currency mismatch", CheckMoneyMismatch),
            ("price conforms to tick", CheckTickConformance),
            ("seeded random is reproducible", CheckSeedReproducible),
        };

        var failed = 0;
        foreach (var (name, check) in checks)
        {
            var ok = check();
            Console.WriteLine($"{(ok ? "PASS" : "FAIL")}  {name}");
            if (!ok)
            {
                failed++;
            }
        }

        Console.WriteLine(failed == 0 ? "selftest: all checks passed" : $"selftest: {failed} check(s) failed");
        return failed == 0 ? 0 : 1;
    }

    private static bool CheckWireRoundtrip()
    {
        var payload = WireParams.Encode(new Dictionary<string, string> { ["strategy_id"] = "demo", ["fast_ma"] = "10" });
        var frame = WireCodec.Encode(MessageType.Initialize, 7, payload);
        var decoded = WireCodec.Decode(frame);
        return decoded.Type == MessageType.Initialize
            && decoded.CorrelationId == 7UL
            && WireParams.Decode(decoded.Payload).Count == 2;
    }

    private static bool CheckWireRejectsTruncated()
    {
        try
        {
            WireCodec.Decode(new byte[8]);
            return false;
        }
        catch (WireException)
        {
            return true;
        }
    }

    private static bool CheckQueueOrder()
    {
        var kernel = new SimulationKernel(DateTimeOffset.Parse("2024-01-02T00:00:00Z"));
        var t0 = kernel.Clock.CurrentUtc;
        kernel.Schedule(EventSource.Strategy, new StrategySignal("s1", "demo", 0.5m), t0);
        kernel.Schedule(EventSource.MarketData, new MarketTick("EURUSD", 1, 1), t0);
        kernel.Schedule(EventSource.Clock, new TimerEvent("t"), t0);
        kernel.Run();
        var kinds = kernel.Trace.Select(e => e.Payload.Kind).ToArray();
        // Same timestamp: MarketData(10) < Timer(20) < StrategyOutput(40).
        return kinds[0] == EventKind.MarketTick && kinds[1] == EventKind.TimerEvent && kinds[2] == EventKind.StrategySignal;
    }

    private static bool CheckMoneyMismatch()
    {
        try
        {
            _ = new Backtest.Core.Primitives.Money(1m, "USD") + new Backtest.Core.Primitives.Money(1m, "EUR");
            return false;
        }
        catch (InvalidOperationException)
        {
            return true;
        }
    }

    private static bool CheckTickConformance()
    {
        var p = new Backtest.Core.Primitives.Price(1.103947m).ConformToTick(0.00001m);
        return p.Value == 1.10395m;
    }

    private static bool CheckSeedReproducible()
    {
        var a = new Backtest.Core.Determinism.SeededRandom(42);
        var b = new Backtest.Core.Determinism.SeededRandom(42);
        for (var i = 0; i < 1000; i++)
        {
            if (a.NextUInt64() != b.NextUInt64())
            {
                return false;
            }
        }

        return new Backtest.Core.Determinism.SeededRandom(0).NextUInt64() == 0xE220A8397B1DCDAFUL;
    }
}
