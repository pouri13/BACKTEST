namespace Backtest.Core.Events;

/// <summary>
/// Deterministic event queue. Ordering key is (TimestampUtc, Rank, SequenceNumber):
/// time first, then the fixed causality rank, then allocation order. This yields a
/// total order for any event multiset, independent of insertion order (rule 9).
/// Implemented as a binary min-heap; Phase 1 may swap in a calendar/queue array
/// without changing the ordering contract.
/// </summary>
public sealed class EventQueue
{
    private readonly List<EventEnvelope> _heap = [];

    public int Count => _heap.Count;

    public void Push(EventEnvelope envelope)
    {
        ArgumentNullException.ThrowIfNull(envelope);
        envelope.EnsureValid();
        _heap.Add(envelope);
        SiftUp(_heap.Count - 1);
    }

    /// <summary>Removes and returns the earliest event; throws if empty.</summary>
    public EventEnvelope Pop()
    {
        if (_heap.Count == 0)
        {
            throw new InvalidOperationException("Event queue is empty.");
        }

        var top = _heap[0];
        var last = _heap[^1];
        _heap.RemoveAt(_heap.Count - 1);
        if (_heap.Count > 0)
        {
            _heap[0] = last;
            SiftDown(0);
        }

        return top;
    }

    public EventEnvelope Peek() => _heap.Count > 0
        ? _heap[0]
        : throw new InvalidOperationException("Event queue is empty.");

    internal static bool Precedes(EventEnvelope left, EventEnvelope right)
    {
        var time = left.TimestampUtc.CompareTo(right.TimestampUtc);
        if (time != 0)
        {
            return time < 0;
        }

        var rank = left.Rank.CompareTo(right.Rank);
        if (rank != 0)
        {
            return rank < 0;
        }

        return left.SequenceNumber < right.SequenceNumber;
    }

    private void SiftUp(int index)
    {
        while (index > 0)
        {
            var parent = (index - 1) / 2;
            if (!Precedes(_heap[index], _heap[parent]))
            {
                break;
            }

            (_heap[index], _heap[parent]) = (_heap[parent], _heap[index]);
            index = parent;
        }
    }

    private void SiftDown(int index)
    {
        while (true)
        {
            var left = (2 * index) + 1;
            var right = left + 1;
            var smallest = index;
            if (left < _heap.Count && Precedes(_heap[left], _heap[smallest]))
            {
                smallest = left;
            }

            if (right < _heap.Count && Precedes(_heap[right], _heap[smallest]))
            {
                smallest = right;
            }

            if (smallest == index)
            {
                return;
            }

            (_heap[index], _heap[smallest]) = (_heap[smallest], _heap[index]);
            index = smallest;
        }
    }
}
