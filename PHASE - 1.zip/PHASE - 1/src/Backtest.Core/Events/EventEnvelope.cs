using Backtest.Core.Time;

namespace Backtest.Core.Events;

/// <summary>Event source component identifiers (docs/architecture/EVENT_MODEL.md).</summary>
public enum EventSource
{
    MarketData,
    Clock,
    Strategy,
    OrderEngine,
    ExecutionEngine,
    PositionEngine,
    AccountEngine,
    RiskEngine,
    PortfolioEngine,
    SnapshotEngine,
    BacktestController,
    System,
}

/// <summary>
/// Deterministic total ordering across same-timestamp events. Lower ranks are
/// processed first. Ranks are fixed in code and enforced by tests so that the
/// engine never depends on insertion order for correctness.
/// </summary>
public enum EventRank : byte
{
    MarketData = 10,
    Timer = 20,
    SimulationControl = 30,
    StrategyOutput = 40,
    Risk = 50,
    OrderState = 60,
    Execution = 70,
    Position = 80,
    Account = 90,
    Telemetry = 100,
}

/// <summary>
/// The unit of exchange inside the engine. Envelopes carry identity, causality
/// and deterministic ordering; payloads carry typed data. Envelopes are immutable.
/// </summary>
public sealed record EventEnvelope
{
    /// <summary>Identity: unique within a simulation run, allocated monotonically.</summary>
    public required long EventId { get; init; }

    /// <summary>Market/physical timestamp; equals the simulation time when produced.</summary>
    public required DateTimeOffset TimestampUtc { get; init; }

    /// <summary>Engine-allocated allocation counter; identical to EventId in Phase 0.</summary>
    public required long SequenceNumber { get; init; }

    /// <summary>Total-ordering rank among events sharing a timestamp.</summary>
    public required EventRank Rank { get; init; }

    public required EventSource Source { get; init; }

    public required IEventPayload Payload { get; init; }

    /// <summary>Causality: EventId of the request/event that caused this event (0 if none).</summary>
    public long CorrelationId { get; init; }

    /// <summary>Causality: EventId of the immediate parent in a derived chain (0 if none).</summary>
    public long ParentEventId { get; init; }

    public static EventEnvelope Create(
        EventSource source,
        IEventPayload payload,
        SimClock clock,
        long allocator,
        long correlationId = 0,
        long parentEventId = 0)
    {
        var envelope = new EventEnvelope
        {
            EventId = allocator,
            SequenceNumber = allocator,
            TimestampUtc = clock.CurrentUtc,
            Rank = payload.Kind.GetRank(),
            Source = source,
            Payload = payload,
            CorrelationId = correlationId,
            ParentEventId = parentEventId,
        };
        envelope.EnsureValid();
        return envelope;
    }

    public void EnsureValid()
    {
        if (EventId <= 0)
        {
            throw new InvalidOperationException($"{nameof(EventId)} must be positive.");
        }

        if (SequenceNumber <= 0)
        {
            throw new InvalidOperationException($"{nameof(SequenceNumber)} must be positive.");
        }

        if (TimestampUtc.Offset != TimeSpan.Zero)
        {
            throw new InvalidOperationException("Event timestamps must be UTC.");
        }

        ArgumentNullException.ThrowIfNull(Payload);
    }
}

public static class EventKindExtensions
{
    /// <summary>Maps payload kinds to their fixed ordering rank.</summary>
    public static EventRank GetRank(this EventKind kind) => kind switch
    {
        EventKind.MarketTick or EventKind.MarketBar or EventKind.MarketDepthUpdate => EventRank.MarketData,
        EventKind.TimerEvent => EventRank.Timer,
        EventKind.BacktestStarted or EventKind.BacktestPaused or EventKind.BacktestResumed
            or EventKind.BacktestCompleted or EventKind.BacktestFailed => EventRank.SimulationControl,
        EventKind.StrategySignal => EventRank.StrategyOutput,
        EventKind.RiskEvent => EventRank.Risk,
        EventKind.OrderRequest or EventKind.OrderAccepted or EventKind.OrderRejected
            or EventKind.OrderCancelled => EventRank.OrderState,
        EventKind.OrderPartiallyFilled or EventKind.OrderFilled => EventRank.Execution,
        EventKind.PositionOpened or EventKind.PositionModified or EventKind.PositionClosed => EventRank.Position,
        EventKind.AccountUpdated => EventRank.Account,
        EventKind.SnapshotCreated => EventRank.Telemetry,
        _ => throw new ArgumentOutOfRangeException(nameof(kind), kind, "Unknown event kind."),
    };
}
