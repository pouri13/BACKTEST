using Backtest.Core.Primitives;

namespace Backtest.Core.Events;

/// <summary>Full catalog of event kinds (docs/architecture/EVENT_MODEL.md §3).</summary>
public enum EventKind
{
    // Market data
    MarketTick,
    MarketBar,
    MarketDepthUpdate,

    // Time
    TimerEvent,

    // Strategy output
    StrategySignal,

    // Order lifecycle
    OrderRequest,
    OrderAccepted,
    OrderRejected,
    OrderCancelled,
    OrderPartiallyFilled,
    OrderFilled,

    // Position lifecycle
    PositionOpened,
    PositionModified,
    PositionClosed,

    // Account
    AccountUpdated,
    RiskEvent,

    // Telemetry / simulation control
    SnapshotCreated,
    BacktestStarted,
    BacktestPaused,
    BacktestResumed,
    BacktestCompleted,
    BacktestFailed,
}

/// <summary>
/// Marker contract for typed event payloads. A payload kind must exist in
/// <see cref="EventKind"/>, carry a fixed ordering rank, and (from Phase 1 on)
/// round-trip through the wire codec.
/// </summary>
public interface IEventPayload
{
    EventKind Kind { get; }
}

// Phase 0 payload set: the full catalog is defined in the specification;
// payloads are added here as engines come online so that no payload type
// exists without a producer contract.

public sealed record MarketTick(string Symbol, decimal Bid, decimal Ask) : IEventPayload
{
    public EventKind Kind => EventKind.MarketTick;
}

public sealed record MarketBar(
    string Symbol,
    DateTimeOffset OpenTimeUtc,
    DateTimeOffset CloseTimeUtc,
    decimal Open,
    decimal High,
    decimal Low,
    decimal Close,
    long Volume) : IEventPayload
{
    public EventKind Kind => EventKind.MarketBar;
}

public sealed record TimerEvent(string TimerId) : IEventPayload
{
    public EventKind Kind => EventKind.TimerEvent;
}

public sealed record StrategySignal(
    string StrategyId,
    string Name,
    decimal Strength) : IEventPayload
{
    public EventKind Kind => EventKind.StrategySignal;
}

public sealed record OrderRejected(
    long OrderId,
    string Symbol,
    string ReasonCode,
    string Message) : IEventPayload
{
    public EventKind Kind => EventKind.OrderRejected;
}

public sealed record OrderCancelled(
    long OrderId,
    string Symbol,
    string ReasonCode,
    bool RequestedByStrategy) : IEventPayload
{
    public EventKind Kind => EventKind.OrderCancelled;
}

public sealed record OrderPartiallyFilled(
    long OrderId,
    string Symbol,
    Quantity FilledQuantity,
    Quantity RemainingQuantity,
    Price FillPrice) : IEventPayload
{
    public EventKind Kind => EventKind.OrderPartiallyFilled;
}

public sealed record OrderFilled(
    long OrderId,
    string Symbol,
    Quantity FilledQuantity,
    Price FillPrice) : IEventPayload
{
    public EventKind Kind => EventKind.OrderFilled;
}

public sealed record PositionOpened(
    long PositionId,
    string Symbol,
    int SignedQuantityLots,
    Price OpenPrice) : IEventPayload
{
    public EventKind Kind => EventKind.PositionOpened;
}

public sealed record PositionModified(
    long PositionId,
    string Symbol,
    int SignedQuantityLots,
    Price AveragePrice) : IEventPayload
{
    public EventKind Kind => EventKind.PositionModified;
}

public sealed record PositionClosed(
    long PositionId,
    string Symbol,
    Money RealizedPnl,
    string Reason) : IEventPayload
{
    public EventKind Kind => EventKind.PositionClosed;
}

public sealed record AccountUpdated(
    string AccountId,
    Money Balance,
    Money Equity,
    Money UsedMargin) : IEventPayload
{
    public EventKind Kind => EventKind.AccountUpdated;
}

public sealed record RiskEvent(
    string Code,
    string Message,
    bool IsBlocking) : IEventPayload
{
    public EventKind Kind => EventKind.RiskEvent;
}

public sealed record SnapshotCreated(
    string SnapshotId,
    long EventId,
    long SequenceNumber) : IEventPayload
{
    public EventKind Kind => EventKind.SnapshotCreated;
}

public sealed record BacktestStarted(string RunId, string Description) : IEventPayload
{
    public EventKind Kind => EventKind.BacktestStarted;
}

public sealed record BacktestPaused(string RunId, string Reason) : IEventPayload
{
    public EventKind Kind => EventKind.BacktestPaused;
}

public sealed record BacktestResumed(string RunId, string Reason) : IEventPayload
{
    public EventKind Kind => EventKind.BacktestResumed;
}

public sealed record BacktestCompleted(string RunId, long EventsProcessed) : IEventPayload
{
    public EventKind Kind => EventKind.BacktestCompleted;
}

public sealed record BacktestFailed(string RunId, string Reason) : IEventPayload
{
    public EventKind Kind => EventKind.BacktestFailed;
}
