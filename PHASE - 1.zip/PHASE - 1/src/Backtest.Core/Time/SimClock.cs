namespace Backtest.Core.Time;

/// <summary>
/// The simulation clock. All engine timestamps are UTC instants produced by this
/// clock — never by wall time — so a run is fully reproducible from its inputs
/// (see docs/architecture/TIME_MODEL.md).
/// </summary>
public sealed class SimClock
{
    private DateTimeOffset _currentUtc;

    /// <summary>The instant simulation processing has reached (inclusive).</summary>
    public DateTimeOffset CurrentUtc => _currentUtc;

    /// <summary>Monotonic counter distinguishing events that share a timestamp.</summary>
    public ulong SubSequence { get; private set; }

    public SimClock(DateTimeOffset initialUtc)
    {
        _currentUtc = Normalize(initialUtc);
    }

    /// <summary>
    /// Advances to <paramref name="utc"/>, which must not be earlier than the
    /// current time. Equal timestamps are allowed (same-instant event batches).
    /// </summary>
    public void AdvanceTo(DateTimeOffset utc)
    {
        var target = Normalize(utc);
        if (target < _currentUtc)
        {
            throw new InvalidOperationException(
                $"Simulation clock cannot move backwards: {_currentUtc:O} -> {target:O}. " +
                "Out-of-order market data must be reordered before entering the engine.");
        }

        if (target > _currentUtc)
        {
            _currentUtc = target;
            SubSequence = 0;
        }
        else
        {
            SubSequence++;
        }
    }

    private static DateTimeOffset Normalize(DateTimeOffset value) => value.ToUniversalTime();
}
