using System.Buffers.Binary;
using System.Text;

namespace Backtest.Core.Wire;

/// <summary>Wire message types for the language-agnostic Strategy API channel.</summary>
public enum MessageType : byte
{
    // Handshake / lifecycle
    Hello = 1,
    HelloAck = 2,
    Initialize = 10,
    InitializeAck = 11,
    Start = 12,
    StartAck = 13,
    Stop = 14,
    StopAck = 15,

    // Events in
    TickEvent = 20,
    BarEvent = 21,
    TimerFire = 22,

    // Requests out
    SubmitOrder = 40,
    CancelOrder = 41,

    // Callbacks in
    OrderUpdate = 50,
    PositionUpdate = 51,
    AccountUpdate = 52,

    // Diagnostics
    Error = 90,
    Ping = 98,
    Pong = 99,
}

/// <summary>Wire error codes (docs/architecture/STRATEGY_API.md §8).</summary>
public enum ErrorCode : ushort
{
    None = 0,
    MalformedMessage = 1,
    UnsupportedVersion = 2,
    UnknownMessageType = 3,
    InvalidParameter = 4,
    NotAllowedInState = 5,
    InternalError = 6,
    Timeout = 7,
}

/// <summary>
/// Wire frame: [u32 length][u16 version][u8 type][u64 corrId][u32 payloadLen][payload].
/// Little-endian; length covers everything after itself. The length prefix lets a
/// transport (stdio, pipe, socket) frame messages without interpreting them.
/// </summary>
public sealed class WireCodec
{
    public const ushort CurrentVersion = 1;
    public const int MinFrameLength = 4 + 2 + 1 + 8 + 4; // 19

    public static byte[] Encode(MessageType type, ulong correlationId, ReadOnlySpan<byte> payload)
    {
        var total = MinFrameLength + payload.Length;
        var buffer = new byte[total];
        BinaryPrimitives.WriteUInt32LittleEndian(buffer, (uint)total);
        BinaryPrimitives.WriteUInt16LittleEndian(buffer.AsSpan(4), CurrentVersion);
        buffer[6] = (byte)type;
        BinaryPrimitives.WriteUInt64LittleEndian(buffer.AsSpan(7), correlationId);
        BinaryPrimitives.WriteUInt32LittleEndian(buffer.AsSpan(15), (uint)payload.Length);
        payload.CopyTo(buffer.AsSpan(MinFrameLength));
        return buffer;
    }

    /// <summary>Parses and validates a frame; throws WireException on any violation.</summary>
    public static WireFrame Decode(ReadOnlySpan<byte> frame)
    {
        if (frame.Length < MinFrameLength)
        {
            throw new WireException(ErrorCode.MalformedMessage, $"Frame too short: {frame.Length} < {MinFrameLength}.");
        }

        var total = BinaryPrimitives.ReadUInt32LittleEndian(frame);
        if (total != frame.Length)
        {
            throw new WireException(ErrorCode.MalformedMessage, $"Length prefix {total} != frame size {frame.Length}.");
        }

        var version = BinaryPrimitives.ReadUInt16LittleEndian(frame.Slice(4));
        if (version > CurrentVersion)
        {
            throw new WireException(ErrorCode.UnsupportedVersion, $"Wire version {version} > supported {CurrentVersion}.");
        }

        // Type byte is not range-checked here: unknown types surface as
        // UnknownMessageType at dispatch time, so forward compatibility is kept.
        var type = (MessageType)frame[6];

        var correlationId = BinaryPrimitives.ReadUInt64LittleEndian(frame.Slice(7));
        var payloadLength = BinaryPrimitives.ReadUInt32LittleEndian(frame.Slice(15));
        if (payloadLength != total - MinFrameLength)
        {
            throw new WireException(ErrorCode.MalformedMessage, $"Payload length {payloadLength} inconsistent with total {total}.");
        }

        var payload = frame.Slice(MinFrameLength).ToArray();
        return new WireFrame(version, type, correlationId, payload);
    }
}

/// <summary>A decoded wire frame.</summary>
public readonly record struct WireFrame(ushort Version, MessageType Type, ulong CorrelationId, byte[] Payload);

/// <summary>Protocol-level error carried across the wire.</summary>
public sealed class WireException(ErrorCode code, string message) : Exception(message)
{
    public ErrorCode Code { get; } = code;
}

/// <summary>Encodes/decodes a string parameter map inside a payload (Initialize/Hello).</summary>
public static class WireParams
{
    public static byte[] Encode(IReadOnlyDictionary<string, string> parameters)
    {
        var sb = new StringBuilder();
        foreach (var (key, value) in parameters.OrderBy(k => k.Key, StringComparer.Ordinal))
        {
            sb.Append(Escape(key)).Append('=').Append(Escape(value)).Append('\n');
        }

        return Encoding.UTF8.GetBytes(sb.ToString());
    }

    public static IReadOnlyDictionary<string, string> Decode(ReadOnlySpan<byte> payload)
    {
        var text = Encoding.UTF8.GetString(payload);
        var result = new Dictionary<string, string>();
        foreach (var line in text.Split('\n', StringSplitOptions.RemoveEmptyEntries))
        {
            var eq = IndexOfUnescaped(line, '=');
            if (eq < 0)
            {
                throw new WireException(ErrorCode.MalformedMessage, $"Parameter line missing '=': '{line}'.");
            }

            result[Unescape(line[..eq])] = Unescape(line[(eq + 1)..]);
        }

        return result;
    }

    private static string Escape(string s) => s
        .Replace("\\", "\\\\", StringComparison.Ordinal)
        .Replace("=", "\\=", StringComparison.Ordinal)
        .Replace("\n", "\\n", StringComparison.Ordinal);

    private static string Unescape(string s)
    {
        var sb = new StringBuilder(s.Length);
        for (var i = 0; i < s.Length; i++)
        {
            if (s[i] == '\\' && i + 1 < s.Length)
            {
                var next = s[i + 1];
                if (next is '=' or '\\' or 'n')
                {
                    sb.Append(next == 'n' ? '\n' : next);
                    i++;
                    continue;
                }
            }

            sb.Append(s[i]);
        }

        return sb.ToString();
    }

    private static int IndexOfUnescaped(string s, char target)
    {
        for (var i = 0; i < s.Length; i++)
        {
            if (s[i] == '\\')
            {
                i++;
                continue;
            }

            if (s[i] == target)
            {
                return i;
            }
        }

        return -1;
    }
}
