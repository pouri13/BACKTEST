namespace Backtest.Core.Determinism;

/// <summary>
/// Deterministic pseudo-random source based on SplitMix64.
/// The .NET <see cref="Random"/> algorithm is not specified by any standard and
/// may change between runtime versions; financial reproducibility (rule 9)
/// requires a fully specified generator instead.
/// </summary>
public sealed class SeededRandom
{
    private ulong _state;

    public SeededRandom(ulong seed) => _state = seed;

    /// <summary>Raw 64-bit output. Reference vector: seed 0 → first value 0xE220A8397B1DCDAF.</summary>
    public ulong NextUInt64()
    {
        _state += 0x9E3779B97F4A7C15UL;
        var z = _state;
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
        return z ^ (z >> 31);
    }

    /// <summary>Uniform in [0, 1) with 53-bit resolution.</summary>
    public double NextDouble() => (NextUInt64() >> 11) * (1.0 / 9007199254740992.0);

    /// <summary>Uniform in [<paramref name="minInclusive"/>, <paramref name="maxExclusive"/>).</summary>
    public int NextInt32(int minInclusive, int maxExclusive)
    {
        if (maxExclusive <= minInclusive)
        {
            throw new ArgumentOutOfRangeException(nameof(maxExclusive), "Must be greater than minInclusive.");
        }

        var range = (long)maxExclusive - minInclusive;
        return (int)(minInclusive + (long)(NextDouble() * range));
    }
}
