namespace Backtest.Core.Primitives;

/// <summary>
/// A price level. Must be strictly positive (market data may carry zero for
/// unavailable sides, represented by absence, not by Price 0) and conform to an
/// instrument's <c>TickSize</c>.
/// </summary>
public readonly record struct Price : IComparable<Price>
{
    public const int MaxDecimalPlaces = 9;

    public decimal Value { get; }

    public Price(decimal value)
    {
        if (value <= 0m)
        {
            throw new ArgumentOutOfRangeException(nameof(value), value, "Price must be strictly positive.");
        }

        Value = decimal.Round(value, MaxDecimalPlaces, MidpointRounding.ToEven);
    }

    public static Price operator +(Price price, Price offset) => new(price.Value + offset.Value);

    public static Price operator -(Price price, Price offset) => new(price.Value - offset.Value);

    public int CompareTo(Price other) => Value.CompareTo(other.Value);

    public static bool operator <(Price left, Price right) => left.Value < right.Value;

    public static bool operator >(Price left, Price right) => left.Value > right.Value;

    public static bool operator <=(Price left, Price right) => left.Value <= right.Value;

    public static bool operator >=(Price left, Price right) => left.Value >= right.Value;

    /// <summary>Rounds to the nearest tick; exact ties round half away from zero.</summary>
    public Price ConformToTick(decimal tickSize)
    {
        if (tickSize <= 0m)
        {
            throw new ArgumentOutOfRangeException(nameof(tickSize), tickSize, "Tick size must be positive.");
        }

        var ticks = Rounding.Round(Value / tickSize, 0, RoundingRule.HalfAwayFromZero);
        return new(ticks * tickSize);
    }

    public override string ToString() => Value.ToString("0.#########", System.Globalization.CultureInfo.InvariantCulture);
}
