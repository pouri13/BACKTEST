using System.Globalization;

namespace Backtest.Core.Primitives;

/// <summary>
/// An exact monetary amount in a specific currency, backed by <see cref="decimal"/>.
/// Amounts carry at most 9 fractional digits; presentation rounding is always
/// explicit via <see cref="RoundToMinorUnits"/>. Arithmetic keeps full precision
/// so rounding decisions are never hidden inside intermediate steps.
/// </summary>
public readonly record struct Money
{
    public const int MaxDecimalPlaces = 9;

    /// <summary>ISO 4217 currency code, e.g. "USD". Never empty.</summary>
    public string Currency { get; }

    /// <summary>Exact amount in major currency units.</summary>
    public decimal Amount { get; }

    public Money(decimal amount, string currency)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(currency);
        if (currency.Length != 3 || currency.Any(c => !char.IsAsciiLetter(c)))
        {
            throw new ArgumentException($"Currency must be a 3-letter ISO 4217 code, got '{currency}'.", nameof(currency));
        }

        Amount = decimal.Round(amount, MaxDecimalPlaces, MidpointRounding.ToEven);
        Currency = currency.ToUpperInvariant();
    }

    public static Money Zero(string currency) => new(0m, currency);

    /// <summary>Rounds to the currency's minor-unit precision (USD→2, JPY→0, …) for reporting.</summary>
    public Money RoundToMinorUnits(RoundingRule rule = RoundingRule.HalfEven)
    {
        var decimals = IsoMinorUnits(Currency);
        return new Money(Rounding.Round(Amount, decimals, rule), Currency);
    }

    public static Money operator +(Money left, Money right)
    {
        EnsureSame(left, right);
        return new Money(left.Amount + right.Amount, left.Currency);
    }

    public static Money operator -(Money left, Money right)
    {
        EnsureSame(left, right);
        return new Money(left.Amount - right.Amount, left.Currency);
    }

    public static Money operator -(Money value) => new(-value.Amount, value.Currency);

    public static Money operator *(Money value, decimal scalar) => new(value.Amount * scalar, value.Currency);

    public static bool operator >(Money left, Money right) => SameCurrency(left, right) && left.Amount > right.Amount;

    public static bool operator <(Money left, Money right) => SameCurrency(left, right) && left.Amount < right.Amount;

    public static bool operator >=(Money left, Money right) => SameCurrency(left, right) && left.Amount >= right.Amount;

    public static bool operator <=(Money left, Money right) => SameCurrency(left, right) && left.Amount <= right.Amount;

    private static bool SameCurrency(Money left, Money right)
    {
        if (left.Currency != right.Currency)
        {
            throw new InvalidOperationException($"Currency mismatch: {left.Currency} vs {right.Currency}.");
        }

        return true;
    }

    private static void EnsureSame(Money left, Money right)
    {
        if (left.Currency != right.Currency)
        {
            throw new InvalidOperationException($"Currency mismatch: {left.Currency} vs {right.Currency}.");
        }
    }

    private static int IsoMinorUnits(string currency) => currency switch
    {
        "JPY" or "KRW" or "VND" or "CLP" or "ISK" => 0,
        "BHD" or "IQD" or "JOD" or "KWD" or "LYD" or "OMR" or "TND" => 3,
        _ => 2,
    };

    public override string ToString() => string.Create(CultureInfo.InvariantCulture, $"{Amount:0.######} {Currency}");
}
