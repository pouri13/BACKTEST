namespace Backtest.Core.Primitives;

/// <summary>
/// Explicit rounding rules for financial values. Every monetary calculation in
/// the engine must name the rule it applies; implicit <c>double</c> rounding is
/// forbidden (see docs/architecture/DECISIONS.md and ADR-0006).
/// </summary>
public enum RoundingRule
{
    /// <summary>
    /// Round half to even (banker's rounding). Default for internal accumulators:
    /// unbiased across large sums, and the default behavior of <see cref="decimal"/> math.
    /// </summary>
    HalfEven,

    /// <summary>
    /// Round half away from zero. Default for client-visible rounding such as
    /// order quantities and instrument-conformant prices.
    /// </summary>
    HalfAwayFromZero,

    /// <summary>Round toward positive infinity (ceiling).</summary>
    Ceiling,

    /// <summary>Round toward negative infinity (floor).</summary>
    Floor,

    /// <summary>Round toward zero (truncate).</summary>
    TowardZero,
}

/// <summary>Maps <see cref="RoundingRule"/> to BCL rounding modes.</summary>
public static class Rounding
{
    public static MidpointRounding ToMidpoint(RoundingRule rule) => rule switch
    {
        RoundingRule.HalfEven => MidpointRounding.ToEven,
        RoundingRule.HalfAwayFromZero => MidpointRounding.AwayFromZero,
        RoundingRule.TowardZero => MidpointRounding.ToZero,
        _ => throw new ArgumentOutOfRangeException(nameof(rule), rule, "Ceiling/Floor must use ToNegativeInfinity/ToPositiveInfinity."),
    };

    public static decimal Round(decimal value, int decimals, RoundingRule rule) => rule switch
    {
        RoundingRule.Ceiling => decimal.Ceiling(value * Pow10(decimals)) / Pow10(decimals),
        RoundingRule.Floor => decimal.Floor(value * Pow10(decimals)) / Pow10(decimals),
        _ => decimal.Round(value, decimals, ToMidpoint(rule)),
    };

    private static decimal Pow10(int decimals)
    {
        ArgumentOutOfRangeException.ThrowIfNegative(decimals);
        ArgumentOutOfRangeException.ThrowIfGreaterThan(decimals, 28);
        decimal result = 1m;
        for (var i = 0; i < decimals; i++)
        {
            result *= 10m;
        }

        return result;
    }
}
