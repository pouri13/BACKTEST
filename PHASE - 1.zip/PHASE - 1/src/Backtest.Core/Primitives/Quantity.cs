namespace Backtest.Core.Primitives;

/// <summary>
/// A tradable quantity expressed in lots/contracts/shares. Must be a non-negative
/// multiple of an instrument's <c>VolumeStep</c>; rounding toward zero is applied
/// explicitly when conforming to a step.
/// </summary>
public readonly record struct Quantity
{
    public const int MaxDecimalPlaces = 8;

    public decimal Value { get; }

    public Quantity(decimal value)
    {
        if (value < 0m)
        {
            throw new ArgumentOutOfRangeException(nameof(value), value, "Quantity cannot be negative.");
        }

        Value = decimal.Round(value, MaxDecimalPlaces, MidpointRounding.ToZero);
    }

    public static Quantity Zero => default;

    public bool IsZero => Value == 0m;

    public static Quantity operator +(Quantity left, Quantity right) => new(left.Value + right.Value);

    public static Quantity operator -(Quantity left, Quantity right)
    {
        if (right.Value > left.Value)
        {
            throw new InvalidOperationException($"Quantity underflow: {left.Value} - {right.Value}.");
        }

        return new(left.Value - right.Value);
    }

    /// <summary>Rounds down to the nearest multiple of <paramref name="step"/>; zero if smaller than one step.</summary>
    public Quantity ConformToStep(decimal step)
    {
        if (step <= 0m)
        {
            throw new ArgumentOutOfRangeException(nameof(step), step, "Volume step must be positive.");
        }

        var steps = decimal.Floor(Value / step);
        return new(steps * step);
    }

    public override string ToString() => Value.ToString("0.########", System.Globalization.CultureInfo.InvariantCulture);
}
