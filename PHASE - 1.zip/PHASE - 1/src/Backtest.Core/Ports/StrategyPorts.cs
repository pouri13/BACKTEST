using Backtest.Core.Events;

namespace Backtest.Core.Ports;

/// <summary>
/// Port for the strategy-side of the Strategy API. Implemented by the engine
/// host; consumed by runtime adapters. Strategies never receive engine
/// internals — only this surface (docs/architecture/STRATEGY_API.md).
/// </summary>
public interface IStrategyContext
{
    /// <summary>Current simulation time (UTC). Always market time, never wall time.</summary>
    DateTimeOffset NowUtc { get; }

    /// <summary>The strategy API version this context speaks.</summary>
    Version ApiVersion { get; }
}

/// <summary>
/// Port implemented by a strategy runtime adapter. The engine calls in; the
/// adapter translates to/from the wire protocol of the chosen language runtime.
/// A crashing adapter must never take the engine down (process isolation is a
/// Phase 3 concern; the seam exists from day one).
/// </summary>
public interface IStrategyRuntime
{
    /// <summary>Stable runtime identifier, e.g. "python", "dotnet-inproc".</summary>
    string RuntimeId { get; }

    Version ApiVersion { get; }

    /// <summary>Lifecycle: load descriptors and initialize state.</summary>
    Task InitializeAsync(StrategyDescriptor descriptor, CancellationToken cancellationToken);

    /// <summary>Lifecycle: begin event processing.</summary>
    Task StartAsync(CancellationToken cancellationToken);

    /// <summary>Lifecycle: deliver one event (tick, bar, timer, order callback…).</summary>
    Task OnEventAsync(EventEnvelope envelope, CancellationToken cancellationToken);

    /// <summary>Lifecycle: graceful stop; final chance to emit state.</summary>
    Task StopAsync(CancellationToken cancellationToken);
}

/// <summary>Identity + metadata for a strategy instance. Wire-visible.</summary>
public sealed record StrategyDescriptor(
    string StrategyId,
    string Name,
    Version ApiVersion,
    IReadOnlyDictionary<string, string> Parameters)
{
    public StrategyDescriptor(
        string strategyId,
        string name,
        Version apiVersion)
        : this(strategyId, name, apiVersion, new Dictionary<string, string>())
    {
    }
}
