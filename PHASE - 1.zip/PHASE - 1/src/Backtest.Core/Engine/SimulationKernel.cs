using Backtest.Core.Determinism;
using Backtest.Core.Events;
using Backtest.Core.Time;

namespace Backtest.Core.Engine;

/// <summary>
/// Deterministic single-threaded simulation kernel — the skeleton every future
/// engine plugs into. It owns the event queue, advances the simulation clock,
/// and produces a full event trace. Determinism contract: identical inputs
/// (events + seed) produce identical traces on any machine (rule 9).
/// The kernel is UI-independent and usable headlessly (rule 7).
/// </summary>
public sealed class SimulationKernel
{
    private readonly EventQueue _queue = new();
    private readonly SeededRandom? _random;
    private readonly List<EventEnvelope> _trace = [];
    private long _nextEventId = 1;
    private KernelState _state = KernelState.Idle;
    private BacktestCompleted? _completion;

    public SimulationKernel(DateTimeOffset startUtc, ulong? randomSeed = null)
    {
        Clock = new SimClock(startUtc);
        if (randomSeed.HasValue)
        {
            _random = new SeededRandom(randomSeed.Value);
        }
    }

    public SimClock Clock { get; }

    public KernelState State => _state;

    /// <summary>Events popped and processed so far, in processing order.</summary>
    public IReadOnlyList<EventEnvelope> Trace => _trace;

    /// <summary>Deterministic pseudo-random source; null when no seed was configured.</summary>
    public SeededRandom? Random => _random;

    public long LastEventId => _nextEventId - 1;

    /// <summary>Schedules an event. Throws if the kernel has stopped.</summary>
    public void Schedule(EventSource source, IEventPayload payload, DateTimeOffset atUtc)
    {
        ObjectDisposedException.ThrowIf(_state is KernelState.Completed or KernelState.Failed, this);
        var envelope = EventEnvelope.Create(source, payload, new SimClock(atUtc), _nextEventId++);
        _queue.Push(envelope);
    }

    /// <summary>
    /// Runs until the queue is empty or the optional deadline (in simulation
    /// time) is reached. Returns the completion payload.
    /// </summary>
    public BacktestCompleted Run(DateTimeOffset? deadlineUtc = null)
    {
        if (_state is KernelState.Completed or KernelState.Failed)
        {
            throw new InvalidOperationException($"Kernel already {_state}; create a new kernel to run again.");
        }

        _state = KernelState.Running;
        while (_queue.Count > 0)
        {
            if (deadlineUtc.HasValue && _queue.Peek().TimestampUtc > deadlineUtc.Value)
            {
                break;
            }

            var envelope = _queue.Pop();
            Clock.AdvanceTo(envelope.TimestampUtc);
            // Sanity: envelope timestamp must equal clock after advancement.
            if (envelope.TimestampUtc != Clock.CurrentUtc)
            {
                _state = KernelState.Failed;
                throw new InvalidOperationException(
                    $"Clock/event time mismatch at event {envelope.EventId}.");
            }

            Process(envelope);
            _trace.Add(envelope);
        }

        _completion = new BacktestCompleted("kernel", _trace.Count);
        _state = KernelState.Completed;
        return _completion;
    }

    /// <summary>Extension point for future engine modules; Phase 0 only records.</summary>
    private void Process(EventEnvelope envelope)
    {
        // Intentionally minimal: the trace IS the contract for Phase 0.
        // Engines subscribe in later phases without changing kernel ordering rules.
    }

    /// <summary>Serializes the trace to canonical NDJSON for determinism comparison.</summary>
    public string TraceToCanonicalJson() => KernelTrace.Join(_trace);
}

public enum KernelState
{
    Idle,
    Running,
    Completed,
    Failed,
}
