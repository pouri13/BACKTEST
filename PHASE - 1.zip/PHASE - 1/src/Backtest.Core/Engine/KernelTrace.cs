using System.Globalization;
using Backtest.Core.Events;

namespace Backtest.Core.Engine;

/// <summary>
/// Canonical serialization of envelopes. One line per event:
/// {"eventId":..,"seq":..,"ts":"..","rank":..,"src":"..","kind":".."}
/// Determinism tests compare these lines byte-for-byte, so the format is frozen:
/// invariant culture, no spaces, ISO-8601 UTC timestamps.
/// </summary>
public static class KernelTrace
{
    public static string ToCanonicalJson(EventEnvelope e) => string.Create(
        CultureInfo.InvariantCulture,
        $"{{\"eventId\":{e.EventId},\"seq\":{e.SequenceNumber},\"ts\":\"{e.TimestampUtc:O}\",\"rank\":{(byte)e.Rank},\"src\":\"{e.Source}\",\"kind\":\"{e.Payload.Kind}\"}}");

    public static string Join(IEnumerable<EventEnvelope> trace) => string.Join('\n', trace.Select(ToCanonicalJson));
}
