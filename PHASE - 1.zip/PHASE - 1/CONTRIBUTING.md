# Contributing to BACKTEST

## Ground rules

1. Read docs/architecture/SYSTEM_ARCHITECTURE.md first — the prime directive is **the core must not depend on the UI**, and dependencies point downward only.
2. All 21 development rules in docs/phases/PHASE_0_REPORT.md apply; the ones contributors most often break: determinism (no wall-clock, no unsourced randomness in runs), decimal-only financial math, no look-ahead access, no stubs presented as features.
3. Minor decisions get a sentence in the PR; major ones get an ADR (docs/architecture/adr/, copy the template structure of existing records).

## Workflow

- Branch from `main`; keep PRs scoped to one module/decision.
- CI must be green: build with zero warnings, format check, all tests (see .github/workflows/ci.yml).
- New code needs tests that would fail without it (ADR-0009: no test, no claim).
- Changing a frozen format (wire, canonical trace, store — once frozen) requires a new version + migration path + updated freeze tests (QG-3).
- Never disable or weaken an existing test to make a suite pass (QG-8); fix the defect or link an issue and quarantine explicitly.

## Code conventions

- `dotnet format` clean; file-scoped namespaces; strict nullable; warnings-as-errors.
- Financial values: `Money`/`Price`/`Quantity` primitives only — raw `decimal`/`double` for financial quantities is a review rejection.
- Time: `SimClock`/event timestamps only; `DateTime.Now` inside simulation logic is a review rejection.
- Public APIs on the strategy surface: document + contract-test before shipping.

## Commit messages

Imperative, scoped, referencing the phase: e.g. `phase-1: add tick store segment writer`.

## Reporting bugs

Include: phase, commit hash, dataset version, and — for nondeterminism reports — two traces (they are byte-comparable by design).
