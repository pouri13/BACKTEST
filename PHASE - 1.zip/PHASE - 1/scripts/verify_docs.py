#!/usr/bin/env python3
"""Documentation consistency check for BACKTEST Phase 0.

Cross-checks that every artifact the phase report claims exists on disk, and
that docs referenced between documents resolve. Exits non-zero on any missing
artifact. Run by the docs gate locally; wired into CI with the build.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# Artifacts the Phase 0 report claims as delivered (checked for existence).
REQUIRED = [
    "README.md",
    "CONTRIBUTING.md",
    "LICENSE",
    ".gitignore",
    ".editorconfig",
    "global.json",
    "Directory.Build.props",
    "BACKTEST.sln",
    "src/Backtest.Core/Backtest.Core.csproj",
    "src/Backtest.Cli/Backtest.Cli.csproj",
    "tests/Backtest.Core.Tests/Backtest.Core.Tests.csproj",
    "src/Backtest.Core/Primitives/Money.cs",
    "src/Backtest.Core/Primitives/Price.cs",
    "src/Backtest.Core/Primitives/Quantity.cs",
    "src/Backtest.Core/Primitives/Rounding.cs",
    "src/Backtest.Core/Time/SimClock.cs",
    "src/Backtest.Core/Determinism/SeededRandom.cs",
    "src/Backtest.Core/Events/EventEnvelope.cs",
    "src/Backtest.Core/Events/Payloads.cs",
    "src/Backtest.Core/Events/EventQueue.cs",
    "src/Backtest.Core/Engine/SimulationKernel.cs",
    "src/Backtest.Core/Engine/KernelTrace.cs",
    "src/Backtest.Core/Ports/StrategyPorts.cs",
    "src/Backtest.Core/Wire/WireCodec.cs",
    "docs/specifications/PRODUCT_REQUIREMENTS.md",
    "docs/specifications/FEATURE_MATRIX.md",
    "docs/architecture/SYSTEM_ARCHITECTURE.md",
    "docs/architecture/TECHNOLOGY_DECISIONS.md",
    "docs/architecture/EVENT_MODEL.md",
    "docs/architecture/TIME_MODEL.md",
    "docs/architecture/MONEY_MODEL.md",
    "docs/architecture/DOMAIN_MODEL.md",
    "docs/architecture/STRATEGY_API.md",
    "docs/architecture/STRATEGY_SANDBOX.md",
    "docs/architecture/SNAPSHOT_SYSTEM.md",
    "docs/architecture/DATA_ARCHITECTURE.md",
    "docs/architecture/PERFORMANCE_ARCHITECTURE.md",
    "docs/architecture/UI_ARCHITECTURE.md",
    "docs/architecture/SECURITY.md",
    "docs/architecture/adr/ADR-0001-architecture-style.md",
    "docs/architecture/adr/ADR-0002-core-ui-separation.md",
    "docs/architecture/adr/ADR-0003-strategy-api-architecture.md",
    "docs/architecture/adr/ADR-0004-data-storage.md",
    "docs/architecture/adr/ADR-0005-event-model.md",
    "docs/architecture/adr/ADR-0006-financial-precision.md",
    "docs/architecture/adr/ADR-0007-ipc-strategy.md",
    "docs/architecture/adr/ADR-0008-snapshot-architecture.md",
    "docs/architecture/adr/ADR-0009-no-fake-implementations.md",
    "docs/testing/TESTING_STRATEGY.md",
    "docs/QUALITY_GATES.md",
    "docs/phases/PHASE_0_REPORT.md",
    ".github/workflows/ci.yml",
]

# Rule references that must hold: forbidden terms must not appear in src code.
FORBIDDEN_IN_SRC = ["metaTrader", "MetaTrader", "MT4", "MT5", "Soft4FX", "TradingView"]


def main() -> int:
    failures: list[str] = []

    for rel in REQUIRED:
        if not (ROOT / rel).exists():
            failures.append(f"missing required artifact: {rel}")

    src_files = [p for p in (ROOT / "src").rglob("*.cs")]
    for path in src_files:
        text = path.read_text(encoding="utf-8", errors="replace")
        for term in FORBIDDEN_IN_SRC:
            if term.lower() in text.lower():
                failures.append(f"forbidden dependency term '{term}' in {path.relative_to(ROOT)}")

    if failures:
        print("verify_docs: FAILED")
        for f in failures:
            print(f"  - {f}")
        return 1

    print(f"verify_docs: OK ({len(REQUIRED)} required artifacts present, "
          f"{len(src_files)} source files clean of forbidden dependency terms)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
