# BACKTEST — Money & Quantity Model

Status: Phase 0. Primitives, rounding rules, and conformance **[implemented]** in `src/Backtest.Core/Primitives/`.

## 1. Decision

All financial values use `System.Decimal` (128-bit, 28 significant digits) — never `float`/`double` for prices, quantities, money, P&L, commission, margin, or fees. Rounding never happens implicitly: every rounding site names its rule via `RoundingRule` **[implemented]**.

## 2. Value domains

| Value | Type | Scale/precision | Internal precision kept? |
|---|---|---| decimals |
| Price | `Price` (decimal, >0) | Instrument `TickSize` grid | Yes — conform only at order/representation boundaries |
| Quantity | `Quantity` (decimal, ≥0) | Instrument `VolumeStep` grid | Yes — conform only when sizing orders |
| Money | `Money` (decimal + ISO currency) | ≤9 dp internally | Yes — round to minor units only for display |
| P&L | `Money` | computed from exact fills | Yes — rounded only in reports |
| Commission/fees | `Money` | per fee model | Yes — accumulate exact, round per instrument spec |
| Margin | `Money` | per margin model | Yes |

## 3. Rounding rules

| Rule | Used for |
|---|---|
| `HalfEven` (banker's) | Default for internal accumulators — unbiased across large sums |
| `HalfAwayFromZero` | Client-visible rounding: quantities, tick-conformant prices |
| `Ceiling`/`Floor` | Margin requirement (Ceiling, conservative), available margin (Floor, conservative) |
| `TowardZero` | Quantity conformance (partial lots dropped) |

Conservatism principle: rounding that increases cost/requirement uses Ceiling; rounding that decreases available funds uses Floor; conformance to instrument grids uses TowardZero for quantity, HalfAwayFromZero for price.

## 4. Conformance

- Prices conform to the instrument tick grid at the moment an order price is created or a simulated fill price is produced **[Price.ConformToTick implemented]**; internal intermediate values (indicators, P&L) never round to the grid.
- Quantities conform to the volume-step grid when sizing orders **[Quantity.ConformToStep implemented]**; partial lots are dropped (TowardZero), a quantity smaller than one step is zero.
- Money accumulates at full precision; only presentation rounds to ISO minor units **[Money.RoundToMinorUnits implemented]**.

## 5. Why not floating point

- 0.1 + 0.2 ≠ 0.3 in binary floating point; P&L across millions of fills accumulates visible drift.
- Comparisons like "equity >= margin requirement" become epsilon-laden and fragile.
- `decimal` costs ~10–50 ns per op — negligible next to queue/dispatch costs; correctness is not for sale here.

## 6. Edge rules (Phase 2 engine obligations)

- Zero-size or negative-result computations are domain errors, not clamped silently.
- Currency conversion (Phase 4, portfolio in multiple currencies) happens only at defined boundaries with the rate recorded in the trace.
- Swap/financing accrual rounds per the instrument spec (documented per instrument); accrual itself accumulates exact.
- Overflow: `decimal` range (±7.9e28) is far beyond realistic account values; checks remain explicit anyway **[Price/Quantity validate on construction]**.
- Determinism: identical config + data + seed must produce byte-identical traces — floating point anywhere in the money path would break this (rule 9).
