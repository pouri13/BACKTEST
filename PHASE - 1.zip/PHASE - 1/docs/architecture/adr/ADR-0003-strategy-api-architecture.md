# ADR-0003 — Strategy API: Wire Protocol + Adapters, Not Embedding

- Status: Accepted
- Date: 2026-09-21
- Phase: 0

## Context

Rule 8 requires a language-agnostic Strategy API. The tempting shortcut is embedding one runtime (usually Python or a JS engine) in-process. That couples the core to one language's GC/ABI, makes crash isolation impossible, and makes the "multi-language" claim dishonest.

## Decision

- The Strategy API is a **binary wire protocol** (STRATEGY_API §2, implemented in `Backtest.Core.Wire`), not a library ABI.
- Every language — including C# — is an **adapter**; C#'s adapter simply runs in-process for trusted strategies (fast path), speaking the same semantics.
- Strategies never touch engine internals; the request/callback surface is the only contract (STRATEGY_API §1).
- Versioned: `wireVersion` in every frame; API versions negotiated at handshake; v1 frozen at Phase 2 GA, compat rule 18 applies.

## Alternatives considered

1. **Embed CPython (pythonnet/embedding)** — rejected: GIL/ABI coupling, crash-domain collapse, version lockstep with our releases.
2. **gRPC/Protobuf as the strategy API** — rejected: no native decimal (precision rule 11), codegen chain, transport weight for a local, lock-step channel.
3. **C#-only plugin DLLs** — rejected: violates rule 8; loading foreign IL into the engine process breaks the trust model.

## Consequences

- Positive: one contract-test suite validating all languages; crash isolation by construction; sandbox fits naturally (process = boundary).
- Negative: IPC overhead for external runtimes (measured budget: ≥50k events/s — acceptable for strategy workloads); adapters are per-language maintenance.
- Enforcement: cross-language contract tests land with each adapter phase; wire version negotiation tested from Phase 2.
