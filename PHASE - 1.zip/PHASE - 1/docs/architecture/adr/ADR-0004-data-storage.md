# ADR-0004 — Data Storage: SQLite Catalog + Custom Columnar Market-Data Store

- Status: Accepted
- Date: 2026-09-21
- Phase: 0

## Context

Two very different storage workloads:

1. Catalog/metadata: symbols, datasets, runs, snapshots, plugins — transactional, relational, low volume.
2. Market data: billions of timestamped, exact-decimal, sequentially-scanned rows — analytics-shaped, append-only, immutable versions.

Also hard constraints: exact decimal precision (rule 11), byte-reproducible replays (rule 9), no server dependency.

## Decision

- **SQLite** for the catalog (public domain, zero-config, transactional, concurrent readers).
- **Custom columnar binary format** for market data: frozen on-disk spec (magic + version header), 100-ns i64 timestamps, scaled-i64 decimals, per-segment CRC, sparse index, block compression (pluggable), immutable version directories.
- Parquet as import/export **interchange** (Phase 2), not the primary store.

## Alternatives considered

1. **All-SQLite** — rejected: row-store tick scans are 10–100× slower than columnar at billion-row scale; blob-encoded decimals inside SQLite lose queryable structure.
2. **Parquet as primary** — rejected: float-typed columns dominate real-world tick Parquet (precision trap); reader/writer dependency weight; sparse-index replay semantics would fight the format.
3. **DuckDB** — rejected as runtime dependency for Phase 1–2; revisit as an embedded analytics accelerator for Phase 4+ reporting only.
4. **Pure memory-mapped structs, no format spec** — rejected: needs the same spec discipline anyway, minus tooling.

## Consequences

- Positive: exact-precision scans at memory speeds; no external runtime; format evolves under our control with explicit versioning.
- Negative: we own format code + a validation/migration tool; third-party tooling must come through import/export adapters.
- Enforcement: Phase 1 gate — store spec doc + round-trip + corruption-rejection tests before the execution engine may depend on it (QG-3).
