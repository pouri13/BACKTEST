# ADR-0008 — Snapshot Architecture: Full-State, Content-Addressed, Branch-Capable

- Status: Accepted
- Date: 2026-09-21
- Phase: 0 (design), 2 (implementation)

## Context

Required capabilities: save → restore → continue; restore → branch → alternative scenario; crash recovery (BT-REL-001); debugging from any past point (BT-DBG-008). All depend on capturing enough state to make the future deterministic.

## Decision

- A snapshot is a **complete state image**: simulation clock (+ sub-sequence), kernel queue (pending events in total order), market-data stream positions + dataset version pin, broker-simulator state (orders/fills/positions/account), per-strategy exported state blobs, RNG state (64-bit, not the seed), execution-model internals, full config, and provenance (engine/API/strategy/dataset versions) — SNAPSHOT_SYSTEM §2.
- **All-or-nothing rule:** if any component cannot be captured (e.g. a strategy without state export), snapshot capture is rejected — partial snapshots are forbidden (they would silently break determinism).
- Snapshots are **immutable, content-addressed** (hash of manifest+payloads); restore validates hashes before starting; branches are new runs whose lineage (parent snapshot → parent run) is stored in the catalog; the only permitted divergence point is a snapshot.
- Trace continuity: continued runs append a new segment referencing the parent; branch never rewrites parent history.

## Alternatives considered

1. **Event-sourcing-only (replay from genesis instead of state images)** — rejected as the primary mechanism: cost grows with run length; snapshots are O(state), not O(history). The event trace remains the audit/rebuild mechanism for short spans and debugging.
2. **Best-effort snapshots (capture what's easy)** — rejected: silent partial state = undetectable nondeterminism later; the all-or-nothing rule is what makes restore trustworthy.
3. **Database-held snapshots (state serialized into catalog tables)** — rejected: couples snapshot format to catalog schema migrations; file-based, hash-addressed artifacts stay loadable across app versions.

## Consequences

- Positive: continue/branch/recover all ride one mechanism; restore equality is testable (continue-to-M == control-run-to-M, byte-identical); crash recovery is the same code path as pause/resume.
- Negative: capture requires strategy cooperation (ExportState/ImportState, STRATEGY_API §6) — non-cooperating strategies are marked non-snapshottable and excluded up front with a clear error, never a corrupt branch.
- Enforcement: Phase 2 determinism gate adds snapshot equality tests; corruption-rejection test (flipped byte → restore refuses).
