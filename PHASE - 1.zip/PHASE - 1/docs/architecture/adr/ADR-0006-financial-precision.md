# ADR-0006 — Financial Precision: Decimal-Only, Named Rounding Rules

- Status: Accepted
- Date: 2026-09-21
- Phase: 0

## Context

Binary floating point cannot represent 0.1 exactly; P&L across millions of fills accumulates drift; comparisons become epsilon-based. Rule 11 demands explicit precision rules. Candidates: double + epsilon discipline, fixed-point ints, IEEE 754 decimal, System.Decimal.

## Decision

- **All** financial values — price, quantity, money, P&L, commission, margin, fees, swap — are `System.Decimal` (128-bit, 28 digits), wrapped in validated primitives (`Price`, `Quantity`, `Money`) that enforce domains and grid conformance **[implemented]**.
- Rounding is never implicit: every rounding site names a rule (`RoundingRule`) — HalfEven for accumulators, HalfAwayFromZero for client-visible values, Ceiling/Floor for conservative margin math, TowardZero for quantity conformance (MONEY_MODEL §3).
- Full precision is carried through computation; rounding to instrument grids or currency minor units happens only at defined boundaries (order creation, fill production, reporting).
- Currency is part of the value (`Money` = amount + ISO code); cross-currency ops are runtime errors, not silent coercion.
- Deterministic seed source (SplitMix64) instead of `System.Random` — `Random`'s algorithm is unspecified across versions and would break cross-machine reproducibility (rule 9).

## Alternatives considered

1. **double + epsilon discipline** — rejected: drift is real, epsilon logic is a bug farm, and rule 9 (byte-identical results) is unverifiable.
2. **Fixed-point int64/int128 everywhere** — viable and fastest, but scales/overflow rules must be hand-rolled per value domain; `decimal` gives the same guarantees with BCL support. Revisit per-hot-path only if profiling demands (allowed: scaled-int inside the data store, ADR-0004 — a storage encoding, not arithmetic).
3. **IEEE 754 decimal floats** — rejected: .NET support is poor and exotic; no ecosystem benefit over `decimal`.

## Consequences

- Positive: exact, explainable money math; grid conformance provable; cross-machine byte equality achievable.
- Negative: `decimal` is slower than double (~10–50 ns/op) — accepted; hot-path profiling may move specific accumulations to scaled ints later behind the same primitive APIs.
- Enforcement: tests pin rounding tables, currency-mismatch rejection, grid conformance, and the PRNG reference vector (all present in Phase 0 tests).
