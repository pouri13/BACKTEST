# ADR-0009 — No Fake Implementations: Honest Status by Contract

- Status: Accepted
- Date: 2026-09-21
- Phase: 0

## Context

The Phase 0 brief forbids stubs pretending to be features (rule 13) and TODO-placeholders-as-deliverables. Long projects die of status rot: code that claims to work but doesn't, docs that describe fiction, tests that assert nothing.

## Decision

1. A feature is "implemented" **only if** it is exercised by an acceptance test that would fail if the feature regressed. No test, no claim.
2. Unimplemented functionality is **documented as planned** (specs/ADR/phase reports carry explicit "Status" fields) — never represented by fake return values, mock data pretending to be real, or UI that says "done" while calling nothing.
3. `TODO` markers are allowed only in compiled sources when they reference a tracked requirement ID; bare TODOs are lint failures. Docs may contain planned-work sections freely.
4. Phase reports list what was **implemented**, **designed**, and **deliberately not implemented** — the third list is mandatory (see PHASE_0_REPORT).
5. Demos may exist (e.g. the Phase 0 CLI) but must be labeled as demos in output and docs, never as product features.

## Alternatives considered

1. **Stub-first development with "fill in later"** — rejected: stubs accrete into load-bearing lies; integration debt compounds invisibly.
2. **No status tracking (trust the code)** — rejected: cross-phase work makes "what's real?" unanswerable without a ledger; phase reports + ADR statuses are that ledger.

## Consequences

- Positive: every status claim in docs is checkable against tests/phase reports; new contributors can trust the README; quality gates have teeth.
- Negative: slightly slower demo velocity — acceptable, this is a correctness-first product.
- Enforcement: QUALITY_GATES QG-1/QG-6 (tests pass, no silent feature removal), verify-docs script cross-checks claimed-vs-existing artifacts.
