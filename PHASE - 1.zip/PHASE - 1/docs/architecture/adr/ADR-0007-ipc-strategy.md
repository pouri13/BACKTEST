# ADR-0007 — Strategy IPC & Isolation: Separate Processes over stdio/Named Pipes

- Status: Accepted
- Date: 2026-09-21
- Phase: 0 (design), 3 (sandbox host implementation)

## Context

Strategies are untrusted (SECURITY §1). Embedding them in-process couples GCs, collapses crash domains, and makes resource limits unenforceable. Windows is the shipping platform.

## Decision

- Every untrusted strategy runs in a **separate OS process**; the engine talks to it over the wire protocol (ADR-0003) via **stdio** (default, most portable) or **named pipes** (same-machine, higher throughput), same frame format on both.
- Resource limits via **Windows Job Objects**: CPU rate, memory commit, per-event wall clock, kill-on-close (STRATEGY_SANDBOX §3). Breach → kill → policy event.
- Dispatch is **lock-step** (one event, one ack): gives clean snapshot boundaries and bounded in-flight state, at the cost of throughput — the accepted trade.
- Trusted in-process C# remains available as an explicit, user-marked exception (TD-9).

## Alternatives considered

1. **AppDomain / AssemblyLoadContext in-process isolation** — rejected: not a security or resource boundary (shared GC, shared threads, no CPU caps); crash domain still shared.
2. **gRPC over localhost** — rejected: heavy stack for a point-to-point byte stream; adds codegen + HTTP/2 machinery without adding a guarantee we need.
3. **Shared-memory ring buffer** — best throughput, but weakens the containment story (shared pages) and complicates backpressure; deferred to Phase 5+ for tick-firehose strategies (BT-FUT-005), behind the same wire semantics.

## Consequences

- Positive: kill/restart semantics are OS-native; a strategy crash is a dead pipe, never an engine crash; limits enforced by the OS, not by our discipline.
- Negative: stdio throughput caps strategy event rates (~50k events/s budget); lock-step dispatch adds latency; Job Objects are Windows-only — acceptable for a Windows-only product (Linux path would use cgroups, documented as future port).
- Enforcement: Phase 3 gates include crash-injection tests (strategy killed mid-run → engine survives → snapshot restart works) and limit-breach tests.
