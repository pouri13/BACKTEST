# ADR-0002 — Core/UI Separation

- Status: Accepted
- Date: 2026-09-21
- Phase: 0

## Context

The product targets a TradingView-grade UI, but charting needs must not contaminate engine design — the classic failure mode of trading platforms. Rule 7 demands a UI-independent core.

## Decision

- `Backtest.Core` references no UI framework and no OS windowing API. Ever.
- The UI consumes the Application layer only: use-case calls + event projections of the same events engines emit.
- Phase 0 ships the core headlessly (CLI + tests prove it). UI work starts Phase 3 as `Backtest.App` (view models) + `Backtest.Gui` (views).
- Application layer is the only adapter between UI and engines; view models never touch engine types directly.

## Alternatives considered

1. **UI-first development** — rejected: chart features would drive engine APIs; determinism and headless testing suffer immediately.
2. **Core-with-UI-hooks (conditional UI code in core)** — rejected: dependency direction always degrades; test matrix explodes.

## Consequences

- Positive: CLI/CI/validation harnesses for free; UI rewrite risk contained; engine testable on any hardware (incl. CI runners without displays).
- Negative: the Application layer must define presentation-friendly projections up front (e.g. event → panel update mapping) — real design work budgeted in Phase 3.
- Enforcement: architecture tests assert Core has no UI package references (QG-2); Phase 0 evidence: `Backtest.Cli` runs the full core with zero UI.
