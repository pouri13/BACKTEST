# ADR-0001 — Architecture Style: Event-Driven Modular Monolith

- Status: Accepted
- Date: 2026-09-21
- Phase: 0

## Context

BACKTEST must evolve from foundation to a professional platform over many phases without re-architecture. Candidate styles: (a) modular monolith, (b) microservices, (c) plugin-heavy host with runtime composition, (d) actor-style concurrency.

Requirements that drive the choice: deterministic byte-identical runs, single-process desktop app, headless usability (CLI/CI), and later parallel backtests.

## Decision

BACKTEST is an **event-driven modular monolith**: one deployable core (`Backtest.Core`) composed of strictly bounded modules communicating through an ordered event queue; process boundaries exist only at the strategy sandbox and (later) optional plugins.

- Single-threaded deterministic kernel; parallelism at the run level (many independent runs), never inside a run.
- Modules communicate via events + ports; no shared mutable state between modules.
- Out-of-process isolation only where trust requires it (strategies, untrusted plugins).

## Alternatives considered

1. **Microservices** — rejected: network hops for local desktop workflows, no need for independent deployment; determinism across process hops is expensive to prove.
2. **In-run multithreaded/actor engine** — rejected as default: nondeterministic ordering risk is fatal to rule 9; concurrency stays outside runs.
3. **Pure library, no kernel** — rejected: without one ordered queue, "every state change is event-caused" becomes convention instead of structure; look-ahead and reproducibility guarantees weaken.

## Consequences

- Positive: provable determinism; simple mental model; headless-first; snapshot/branch semantics fall out of the single ordered queue.
- Negative: one slow module stalls a run (acceptable: strategies are the slow part and live out-of-process); per-core throughput ceiling acknowledged in PERFORMANCE_ARCHITECTURE with an escape hatch (native plugin behind ports).
- Enforcement: CI architecture tests (no UI deps in core, no up-references), quality gate QG-2.
