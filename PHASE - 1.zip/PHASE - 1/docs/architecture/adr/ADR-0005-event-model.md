# ADR-0005 — Event Model: Single Ordered Queue with Fixed Ranks

- Status: Accepted
- Date: 2026-09-21
- Phase: 0

## Context

Every guarantee the product makes — determinism (rule 9), no look-ahead (rule 10), event-sourced debugging, snapshot/branch — depends on one thing: a total order over all events that is provably independent of insertion order, timing, or machine.

## Decision

- One **priority queue per run**; ordering key **(TimestampUtc, Rank, SequenceNumber)** — a total order.
- **Ranks are fixed per event kind** (EVENT_MODEL §2), encoding causality (market → timer → control → strategy → risk → order → execution → position → account → telemetry) so same-instant events order deterministically without timestamps fighting each other.
- Envelopes carry identity (EventId), causality (CorrelationId, ParentEventId), and are immutable.
- Payload types ship only when their producing engine ships (no orphan payloads); the kind enum is the full catalog from day one.
- Canonical NDJSON trace format is byte-frozen and culture-independent for cross-machine comparison.

## Alternatives considered

1. **Multiple per-source queues merged at read** — rejected: merge order becomes an implicit second ordering system; determinism proofs get much harder.
2. **Timestamp-only ordering with insertion-order tie-break** — rejected: insertion order is machine/scheduling-dependent → nondeterminism.
3. **Fully dynamic priorities** — rejected: rank is exactly what prevents "who registered first wins" bugs.
4. **Lock-free parallel dispatch inside a run** — rejected: violates the single-threaded kernel decision (ADR-0001); deterministic async joins are a research problem, not an engineering one.

## Consequences

- Positive: byte-identical traces across machines; snapshots only need the queue image + RNG + stream positions; debugging replays become trivial.
- Negative: rank table is a compatibility surface — new kinds must join existing ranks or ship a new documented rank with test updates; same-timestamp semantics are fixed forever (v1 contract).
- Enforcement: ordering and insertion-independence tests exist in Phase 0 (`ArchitectureValidationTests`); canonical-format freeze test included.
