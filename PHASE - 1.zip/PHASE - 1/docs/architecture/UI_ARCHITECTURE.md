# BACKTEST — UI Architecture

Status: Phase 0 — design only. UI implementation starts Phase 3 (ADR-0002 keeps it out of the core until then).

## 1. Law

The UI contains **zero domain logic**. It renders state delivered by the Application layer and translates user gestures into use-case calls. If a rule about orders, P&L, or time can be violated from the UI, the architecture is wrong — validation lives in Core/Application.

## 2. Shell

```
┌────────────────────────────────────────────────────────────────┐
│ Toolbar: run controls · replay transport · profile selector    │
├───────────┬────────────────────────────────────┬───────────────┤
│ Watchlist │  Chart area (tabbed, tiling)       │ Depth/DOM     │
│ (symbols) │  one chart per tab, multi-layout   │ (Phase 5)     │
├───────────┴────────────────────────────────────┼───────────────┤
│ Orders │ Positions │ Account │ Trade history      │ Strategy panel│
├────────────────────────────────────────────────┴───────────────┤
│ Timeline · replay controls (Phase 3)                           │
├────────────────────────────────────────────────────────────────┤
│ Debug panel / Logs (event inspector, decision log)             │
└────────────────────────────────────────────────────────────────┘
```

- **Docking:** full dock/float/tab/split layout persisted per workspace profile (Phase 3 custom Avalonia dock control).
- **Multi-chart/multi-symbol:** independent chart instances bound to separate view models; synchronized crosshair/zoom groups are opt-in per layout.
- **Project management:** a "workspace" bundles layout, open charts, active runs, and data selections; saved as JSON.

## 3. Panels and their data contracts (Application layer provides; UI never computes)

| Panel | Reads | Writes (use-cases) |
|---|---|---|
| Chart | bars/ticks window, indicator series, drawings, replay cursor | place/drag orders, drawings persistence |
| Watchlist | symbol snapshot quotes | symbol selection |
| Order panel | working orders | submit/modify/cancel |
| Positions panel | open positions, live P&L | close/partial/modify SL/TP |
| Account | balance/equity/margin | deposit/reset (sim) |
| Strategy panel | strategy list, state, params | attach/detach, param edit, start/stop |
| Debug panel | event trace, decision log, breakpoints | run/pause/step, snapshot/branch |
| Logs | filtered event streams | export |
| Timeline | run position, markers (trades, snapshots, branches) | seek (replay), snapshot jump |

## 4. State delivery model

- The UI subscribes to Application-layer event streams (the same events engines emit — EVENT_MODEL §3 filtered/projection-mapped for presentation).
- View models are the ONLY place UI state exists; they are updated by events and are trivially testable headlessly.
- Live replay = the Application layer pumps events at replay speed; the UI is a passive renderer. No timers in views driving engine state, ever.
- Threading: engines emit on engine threads; the Application layer marshals to the UI thread via the framework dispatcher; view models never call engines directly.

## 5. Chart rendering approach (Phase 3)

- Custom Skia canvas (TD-8): candles/bars/line/area in Phase 3; Heikin Ashi/Renko/Range/tick/second charts derived via the same transformation pipeline as the data engine (they are data transforms, not chart features — the chart renders whatever bars it is given).
- Interaction: zoom/pan are viewport transforms over a virtual time axis; crosshair hit-testing is data-space, keeping 60 fps with >100k visible bars via viewport decimation.
- Replay cursor is a chart-viewport concept bound to simulation time; drawing tools persist as workspace artifacts, never as market data.

## 6. Visual language

TradingView-inspired (dark-first theme, clean grid, restrained color semantics: green/red direction, blue selection) — implemented as a theme token set (colors, spacing, typography) applied across all controls. Original assets only (rule 5/6).

## 7. Phase 0 position

No UI code exists and none should — Phase 0 proves the core headlessly. The only UI-adjacent artifacts are this document, the event contracts it consumes, and the decision that ViewModels will live in a separate `Backtest.App` project so they stay testable without a display.
