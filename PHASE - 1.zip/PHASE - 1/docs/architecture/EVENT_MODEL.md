# BACKTEST — Event Model

Status: Phase 0. The envelope, ordering ranks, queue, and the Phase 0 payload subset are **[implemented]** in `src/Backtest.Core/Events/`.

## 1. Envelope

Every event exchanged inside the engine is an immutable envelope:

| Field | Type | Meaning |
|---|---|---|
| `EventId` | long | Unique within a run, allocated monotonically by the kernel. Identity anchor for correlation. |
| `SequenceNumber` | long | Allocation-order counter; final tie-breaker of the total order. Equals `EventId` in Phase 0. |
| `TimestampUtc` | DateTimeOffset | UTC instant the event belongs to (simulation time; equals market time for market data). Offset must be zero. |
| `Rank` | EventRank (byte) | Fixed causality rank; the second ordering key. |
| `Source` | EventSource | Producing component (MarketData, Clock, Strategy, OrderEngine, …). |
| `Payload` | IEventPayload | Typed data record. One kind per payload type. |
| `CorrelationId` | long | `EventId` of the request that caused this event (0 = none). Lets a fill be traced to its order request. |
| `ParentEventId` | long | `EventId` of the immediate parent in a derived chain (0 = root). |

## 2. Deterministic total order

Ordering key: **(TimestampUtc, Rank, SequenceNumber)** — a total order over any event multiset, independent of insertion order. Proven by `Queue_is_insertion_order_independent`.

Fixed ranks (byte values, lower first):

| Rank | Value | Kinds |
|---|---|---|
| MarketData | 10 | MarketTick, MarketBar, MarketDepthUpdate |
| Timer | 20 | TimerEvent |
| SimulationControl | 30 | BacktestStarted/Paused/Resumed/Completed/Failed |
| StrategyOutput | 40 | StrategySignal |
| Risk | 50 | RiskEvent |
| OrderState | 60 | OrderRequest, OrderAccepted, OrderRejected, OrderCancelled |
| Execution | 70 | OrderPartiallyFilled, OrderFilled |
| Position | 80 | PositionOpened, PositionModified, PositionClosed |
| Account | 90 | AccountUpdated |
| Telemetry | 100 | SnapshotCreated |

Rationale: at one instant, causality flows market → strategy → order → execution → position → account. A strategy therefore never sees its own fill before the execution event that caused it, and account state is always consistent when observed at a tick boundary.

Ranks are fixed in code and pinned by test; adding a kind requires assigning it to an existing rank (or a documented new rank) plus a test update — never an ad-hoc value.

## 3. Payload catalog

Full planned catalog (payload types appear in code as their engines come online — no payload without a producer):

| Kind | Producer | Consumer | Planned payload (summary) |
|---|---|---|---|
| MarketTick | Market Data Engine | Strategies, Broker Sim | Symbol, Bid, Ask, optional Last/Volume/Depth flags |
| MarketBar | Market Data Engine | Strategies, Broker Sim | Symbol, OHLCV, open/close time |
| MarketDepthUpdate | Market Data Engine | Book strategies (Phase 5) | Symbol, side, price level, new volume |
| TimerEvent | Clock Engine | Strategies, engines | TimerId, due time, period flags |
| StrategySignal | Strategy runtime | Debug log, analytics | StrategyId, signal name, strength, optional note |
| OrderRequest | Strategy via runtime | Broker Sim | OrderId, symbol, side, type, quantity, price, TIF, SL/TP |
| OrderAccepted | Broker Sim | Strategy, UI, logs | OrderId, broker timestamp |
| OrderRejected | Broker Sim | Strategy, UI, logs | OrderId, reason code, message |
| OrderCancelled | Broker Sim | Strategy, UI, logs | OrderId, reason, requester |
| OrderPartiallyFilled | Execution Model | Strategy, Position Engine | OrderId, fill qty, remaining, price |
| OrderFilled | Execution Model | Strategy, Position Engine | OrderId, fill qty, price, commission |
| PositionOpened | Position Engine | Strategy, analytics | PositionId, symbol, signed qty, open price |
| PositionModified | Position Engine | Strategy, analytics | PositionId, qty, avg price |
| PositionClosed | Position Engine | Strategy, analytics | PositionId, realized P&L, reason |
| AccountUpdated | Account Engine | Strategy, UI, risk | Balance, equity, margin used/free |
| RiskEvent | Risk Engine | Strategy, UI, logs | Code, severity, blocking flag |
| SnapshotCreated | Snapshot Engine | UI, catalog | SnapshotId, position in trace |
| BacktestStarted/Paused/Resumed | Controller | UI, logs | RunId, reason |
| BacktestCompleted | Controller | Reports, UI | RunId, events processed |
| BacktestFailed | Controller | Reports, UI | RunId, failure reason |

## 4. Serialization strategy

- In-memory: typed records, no serialization during a run (zero-cost hot path).
- Trace/logs: canonical NDJSON line per event **[implemented]** — `KernelTrace.ToCanonicalJson`, byte-frozen format, invariant culture. Determinism tests compare traces byte-for-byte.
- Wire (to strategy processes): binary frames (WireCodec **[implemented]**), payload schemas versioned with the Strategy API.
- Long-term storage (Phase 1): same NDJSON for human-tool compatibility; the columnar store for bulk market data. Binary event-log format for billion-event traces is a Phase 2 decision recorded in ADR-0005.

## 5. Delivery rules

- Exactly-once, in-order delivery to each consumer; consumers never re-order.
- No synchronous re-entrancy: handlers may enqueue, never push-and-run inline (enforced from Phase 1 by the kernel loop; the rule is already documented here).
- Every event is either consumed by at least the trace recorder (default) or explicitly filtered; silent drops are forbidden.
