# BACKTEST — Data Architecture

Status: Phase 0 — design; store implementation is Phase 1 (ADR-0004).

## 1. Principles

1. Market data is **immutable source data** (rule 19). Fixes create new dataset versions; raw files are never rewritten.
2. Validation is a pipeline stage, not an afterthought: no dataset enters the catalog without passing the checks in §6.
3. Everything the engine replays must be byte-reproducible: dataset ID + version pins the exact bytes a run used.

## 2. Data types

| Type | Fields | Storage |
|---|---|---|
| Tick (quote) | symbol, ts, bid, ask, sizes | columnar binary (§5) |
| Tick (trade) | symbol, ts, price, size, aggressor side | columnar binary |
| Bar (OHLCV) | symbol, tf, open/close time, O/H/L/C, volume | columnar binary |
| Depth | symbol, ts, side, level, price, size | columnar binary (Phase 5) |
| Instrument metadata | tick size, steps, calendars, fees | SQLite catalog |

## 3. Format comparison (evaluated, per the Phase 0 brief)

| Criterion | Custom columnar binary | Parquet | SQLite | Memory-mapped raw |
|---|---|---|---|---|
| Precision | exact (scaled int64/128-bit decimal layout) | exact if using fixed-landing decimal, else float trap | exact (text/decimal affinity is fragile) | exact (own layout) |
| Billion-row sequential scan | fastest possible (own layout, no row overhead) | fast, but decode overhead + float-typed columns common in the wild | slow (row store) | fastest (it *is* the scan) |
| Random access/indexing | own sparse index | good via row-group stats | good | own index |
| Compression | block (LZ4/zstd-pluggable, Phase 1) | strong built-in | page-level only | none |
| Tooling/ecosystem | ours to build | excellent (Arrow/duckdb/pandas interop) | excellent | none |
| Dependency weight | none (in-repo format) | reader/writer libs | SQLite engine | none |
| Multi-venue symbol organization | own manifest | per-file, external org | good (tables) | own manifest |

**Decision (TD-3/ADR-0004):** custom columnar binary for the engine-facing store; Parquet supported as an **import/export interchange format** (Phase 2) — not the primary store, because most real-world Parquet tick data is float-typed (precision loss) and the engine needs exact decimals plus our own sparse-index replay semantics. SQLite for the catalog only.

## 4. Store layout (Phase 1 contract)

- One dataset = one symbol/timeframe/venue/version: `<data-root>/<venue>/<symbol>/<type>_<tf>/v<major>.<minor>/`.
- Version directories are immutable; a version is a sequence of **segment files** (fixed rows per segment, e.g. 1M ticks) + a manifest (row counts, min/max timestamps, hash chain).
- Columns: timestamp (i64 100-ns ticks), bid/ask/price (i64 scaled by instrument decimals), sizes (i64), flags (u8). All little-endian. A frozen format spec with magic + version header ships with Phase 1 code.
- Sparse index every N rows → cheap time-range seeks; segments independently CRC-checked; corrupt segment ⇒ dataset validation fails.

## 5. Import/export

CSV/JSON import (Phase 1): streaming parsers, strict schemas, progress reporting, cancelable. Import always produces a new immutable version — never appends to existing data. Parquet in/out (Phase 2). Custom formats via data-source plugins (Phase 5) implementing the same `IDataSource` port.

## 6. Validation rules (pre-catalog)

1. Timestamps strictly non-decreasing per segment (violations → derive a sorted version, report both).
2. Prices positive and bid ≤ ask for quotes; OHLC relations hold (H ≥ max(O,C), L ≤ min(O,C), H ≥ L).
3. Grid conformance: prices on tick grid (within vendor tolerance), sizes on step grid.
4. Gap analysis vs session calendar (TIME_MODEL §6); gaps reported, not silently filled.
5. Duplicate detection (same ts+values).
6. All-or-nothing catalog entry: a dataset version is registered only if 100% of checks pass; partial imports are discarded with a report.

## 7. The engine view: `IDataSource`

Forward-only, time-ordered iteration over (symbol, type, timeframe) with explicit gap markers; no look-ahead access (rule 10). Multi-symbol replays use a k-way merge across per-symbol streams — ordering contract identical to EVENT_MODEL §2. Alignment across timeframes is derived from the calendar, not from wall-time heuristics.

## 8. Multi-venue and symbols

Venue = namespace for symbols + calendars + fee models. Cross-venue runs (Phase 5) merge streams with venue-prefixed symbol IDs; venue-specific break handling stays in the calendar layer.
