# BACKTEST — Strategy Sandbox

Status: Phase 0 — architecture only. Nothing here is implemented yet; the sandbox host is a Phase 3 deliverable. The seams it needs (wire protocol, dispatch lock-step, per-run policy config) already exist.

## 1. Isolation model

Every third-party or untrusted strategy runs in a **separate OS process** (the "strategy host process"). The engine never loads foreign code into its own address space. Consequences:

- A strategy crash (segfault, unhandled exception, OOM kill) cannot take the engine down — the engine sees a dead pipe, records a `BacktestFailed`/strategy-failure event, and follows restart policy.
- In-process C# adapters (TD-9) are allowed only for strategies the user explicitly marks as trusted; the default trust boundary is the process.

## 2. Process boundaries

| Boundary | Mechanism |
|---|---|
| Address space | Separate process; IPC only via the wire protocol |
| Handle inheritance | None by default — the host process gets exactly two pipes (stdio) + its strategy directory |
| Working directory | Sandboxed strategy work dir; engine paths are never exposed |
| Environment | Minimal env vars (wire version, strategy ID, run ID); no user secrets |

## 3. Resource limits (enforced by the host, configured per run)

| Limit | Default (planned) | Enforcement |
|---|---|---|
| CPU time per event | 1 s soft / 10 s hard | Host stopwatch around dispatch; soft → warning event, hard → terminate |
| Total CPU per run | Configurable | Job object (Windows) CPU rate control |
| Memory | e.g. 512 MB per strategy | Job object memory notification → kill on breach |
| Output bandwidth | Frames/run bounded | Host counters; breach → terminate (runaway strategy) |
| Wall-clock per event | same as CPU hard | Prevents sleeping strategies |

Windows Job Objects are the enforcement primitive (process tree-wide limits, kill-on-close); this is a Windows-only feature by design (the product is Windows-only).

## 4. Timeouts and deadlock

- Dispatch is lock-step (STRATEGY_API §3): the host sends one event and awaits the ack. A missed ack within the hard timeout = hang → kill.
- Ping/Pong heartbeat at configurable intervals during long user-code stretches (e.g. initialization).
- A killed strategy enters `Failed`; per policy the run either fails, skips the strategy, or restores from the last snapshot and re-runs with the strategy disabled (§7).

## 5. Permissions (Phase 3 capability model)

| Capability | Grant model |
|---|---|
| File system | Only the strategy's own work directory, session-scoped |
| Network | **Denied by default.** Grant requires explicit user approval, recorded in the run config |
| Process creation | Denied |
| Clipboard/UI | Denied |
| Clock | Simulation time only — the host never exposes wall time |

Permissions are declared by the strategy manifest, shown to the user at attach time, and recorded in every run produced with them. Runs record which capabilities were granted — a permission change invalidates comparability of results, which must be visible.

## 6. Kill/restart behavior

```
normal stop:   Stop → StopAck (grace period) → process exit → drained pipe → done
policy kill:   hard timeout / OOM / bandwidth → Job-Object kill → Failed event
restart:       allowed only from a snapshot taken before the failure point
               (determinism rule 9 forbids "resume mid-stream" with lost state)
```

Restart-with-replay is possible because the event trace is deterministic: restore snapshot → truncate trace after snapshot point → re-run. This is the same machinery as branching (SNAPSHOT_SYSTEM §4), so it comes almost for free.

## 7. Interaction with snapshots

- Snapshot capture requires all attached strategies to support ExportState (STRATEGY_API §6) or the run to be at a strategy-idle boundary. The snapshot records which mode was used.
- A strategy that cannot export state is marked non-snapshottable; branching such a run is rejected up front with a clear reason rather than producing a corrupt branch.

## 8. Explicitly out of scope (Phase 0)

Implementing the host process, Job Objects, or the permission UI. This document is the contract Phase 3 builds against; the ADR for process isolation is ADR-0007.
