# BACKTEST — Domain Model: Orders & Execution

Status: Phase 0. Contracts and state machines only — the engines are Phase 2. Nothing here is faked as complete.

## 1. Entities

### Instrument
Immutable definition of a tradable symbol.

| Field | Notes |
|---|---|
| Symbol, Description | Identity |
| AssetClass | Forex, CFD, Futures, Crypto, Equity, … |
| TickSize, Decimals | Price grid (MONEY_MODEL §4) |
| VolumeStep, MinVolume, MaxVolume | Quantity grid |
| ContractSize | Value of one unit of quantity |
| QuotedCurrency, ProfitCurrency, MarginCurrency | Currencies for P&L/margin math |
| CommissionModel, SwapModel, MarginModel | References to fee/margin configs |
| TradingCalendar | Sessions/holidays (TIME_MODEL §3) |

### Order
An instruction; immutable once accepted except for documented modifications.

| Field | Notes |
|---|---|
| OrderId, RequestEventId | Identity + causality (correlation to OrderRequest) |
| Symbol, Side (Buy/Sell), Type | Market, Limit, Stop, StopLimit |
| Quantity | Requested (Quantity) |
| LimitPrice, StopPrice | Optional per type |
| TimeInForce | GTC, Day, IOC, FOK |
| StopLoss, TakeProfit | Optional attached exits |
| TrailingStopConfig | Optional (distance/step rules) |
| BreakEvenConfig | Optional trigger rules |
| OcoGroupId | Optional link (one-cancels-other) |
| State | See state machine |
| FilledQuantity, RemainingQuantity | Maintained by execution engine |

**Order state machine (Phase 2 contract):**

```
Created → Submitted → Accepted ──► Working ──► PartiallyFilled ──► Filled
                │            │             │
                └── Rejected └─ Cancelled ──┴── Cancelled (from PartiallyFilled)
                                  Expired (TIF) from Working/PartiallyFilled
```

Terminal states: Filled, Cancelled, Rejected, Expired. No transition leaves a terminal state.

### Fill
One execution event against an order: FillId, OrderId, Quantity, Price, Commission, TimestampUtc, LatencyApplied. An order with partial fills accumulates several fills; `OrderFilled` fires on terminal fill.

### Position
Net exposure per symbol per account (netting model, matching Soft4FX-style accounting).

| Field | Notes |
|---|---|
| PositionId, Symbol, AccountId | Identity |
| SignedQuantity | >0 long, <0 short |
| AveragePrice | Volume-weighted from fills (exact decimal) |
| RealizedPnl, UnrealizedPnl | Computed; unrealized always from current simulated bid/ask |
| SwapAccrued | Financing accrued by session calendar |
| StopLoss, TakeProfit, Trailing, BreakEven | Working exit management |

### Trade
A completed round-trip: entry fill(s) + exit fill(s), with realized P&L, commission, swap, duration. The atomic unit of all analytics and reports.

### Account
Balance, Equity, UsedMargin, FreeMargin, MarginLevel, Currency. All mutations are event-sourced from fills/positions (AccountUpdated events).

### BrokerSimulator (port `IBrokerSimulator`, Phase 2)
The composition of execution model + fee models + margin model + session calendar. Strategies never talk to it directly; they submit `OrderRequest` events.

### ExecutionModel (port `IExecutionModel`, Phase 2)
Given (order, market state at decision time, config) → produces fill/reject/defer decisions. Pluggable implementations: idealized (zero spread), realistic (spread + slippage + latency + partial fills). The interface — not any specific model — is the contract.

## 2. Execution realism switches (Phase 2 requirements)

Spread (bid/ask crossing rules), commission (per lot/per trade, entry+exit), swap (triple-day rules per calendar), slippage (fixed, variable, or distribution-based — seeded RNG only), latency (order + fill delay in simulation time), partial fills (volume-capped), rejections (margin, market closed, invalid price), market closure handling (queue until next session or reject — configurable).

## 3. Guarantees

1. Every fill is caused by exactly one order and one market event; both are recorded via correlation IDs.
2. Fill prices always conform to the instrument tick grid and always respect the side rule: buys fill at ask (+slippage), sells at bid (−slippage) — never the reverse.
3. The execution engine never inspects events beyond the current simulation time (rule 10).
4. Position P&L math uses only exact decimals (MONEY_MODEL).
5. All state transitions emit the events listed in EVENT_MODEL §3 — no silent mutations.
