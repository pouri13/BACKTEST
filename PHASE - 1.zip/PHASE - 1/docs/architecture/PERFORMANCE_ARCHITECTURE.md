# BACKTEST — Performance Architecture

Status: Phase 0 — identifies the real bottlenecks and the optimization plan; no premature tuning. Phase 0 numbers are budgets, not claims.

## 1. Design targets (budget model, Phase 2 revisits with measurements)

| Scenario | Target |
|---|---|
| Tick replay, no strategies | ≥ 5M events/s single core |
| Tick replay + 1 in-process C# strategy | ≥ 1M events/s |
| Replay + strategy over stdio IPC | ≥ 50k events/s (IPC-bound by design) |
| Optimization, 16 cores | linear-ish scaling until IPC/disk bound |

These are budgets to validate in Phase 2 perf tests — explicitly not Phase 0 claims.

## 2. The actual bottlenecks (in order)

1. **Event queue operations** — pop/push dominate every run. Mitigation: binary heap now **[implemented]**; Phase 2 keeps a hot-path allocation-free loop (pooled envelopes, array-based tiers for same-timestamp batches).
2. **Serialization** — canonical NDJSON is a trace/debug format, never the hot path; bulk traces are written in batches to a stream, not string-concatenated.
3. **Market data decode** — columnar reads are sequential; scaled-int columns decode without allocation.
4. **IPC for external strategies** — stdio is the bottleneck *by design* (sandbox > raw speed); the model limits events per strategy (subscriptions + lock-step dispatch). Shared-memory transport remains a Phase 5+ option for tick-firehose strategies.
5. **GC pressure** — `decimal` and envelopes allocate. Phase 1–2 rules: no per-event LINQ/string ops on the hot path; pooled envelope buffers; batched trace writes. `struct` primitives (already used) avoid heap traffic for Money/Price/Quantity.
6. **Memory for billion-event datasets** — never fully resident: segment streaming (DATA_ARCHITECTURE §4) with read-ahead; the kernel needs only the pending queue, which is bounded by event horizon.

## 3. Sequential core, parallel runs

The simulation core is deliberately **single-threaded** (determinism, rule 9). Parallelism lives at the run level:

- Optimization/walk-forward/Monte Carlo = many independent runs → process-per-run or task-per-run over the in-process kernel, work-stealing across cores (Phase 5).
- Determinism is per-run; concurrent runs share read-only datasets via memory-mapped segments.
- No shared mutable state between runs; artifacts are per-run directories.

## 4. Zero-copy / memory mapping (where it actually pays)

- Market-data segments: memory-mapped, read sequentially; the sparse index lets a replay start mid-dataset without reading the head.
- Trace files: append-only, batched writes; reading a trace for reports uses the same mapping.
- Snapshots: write the queue/state images directly from their backing buffers where possible (Phase 2 decision during implementation).

## 5. What is deliberately NOT optimized yet

- Chart rendering perf (Phase 3 problem).
- Optimization fan-out (Phase 5 problem).
- IPC throughput beyond what lock-step dispatch needs (sandbox semantics own that trade-off).
- Any hot-path micro-optimization before Phase 2 produces measurements. Phase 0 shipped struct primitives and an allocation-conscious queue instead of speculative machinery.

## 6. Measurement discipline

Perf tests are guarded (TESTING_STRATEGY §Performance): assert relative budgets (e.g. N events/sec floor on CI hardware class) rather than absolute times, to avoid flaky CI. Every optimization PR must show a benchmark delta or it does not get merged — matching the quality gates.
