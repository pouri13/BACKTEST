# BACKTEST — Technology Decisions

Status: Phase 0. Every decision records alternatives and consequences so future phases revisit them through the ADR process rather than by silent drift.

## Executive summary

| Layer | Decision | One-line reason |
|---|---|---|
| Core engine | C# / .NET 8 (LTS) | Best balance of throughput, Windows integration, ecosystem, maintainability |
| UI | Avalonia (Phase 3) | XAML/MVVM, GPU composition, native-feel Windows desktop |
| Charting | In-repo Skia canvas (Phase 3) | The chart is the product; owning the renderer avoids mid-project migration |
| Storage | SQLite catalog + custom columnar market-data store | Transactional metadata vs billion-row sequential scans, both exact-precision |
| IPC | Length-prefixed frames over stdio / named pipes | Most portable sandbox boundary; one codec for all transports |
| Serialization | Custom binary wire (v1) + JSON for config/reports | Exact decimal round-trip on the wire; humans read config and reports |
| Testing | xUnit | Ecosystem default, fast, good theory support |
| Build | Plain MSBuild + `dotnet` CLI | Zero machinery; identical locally and in CI |
| CI | GitHub Actions, Windows runners | Validate the actual shipping platform |
| Packaging | MSIX (Phase 5), zip from Phase 3 | Native auto-update; early adopters get a portable zip |

## Decision records

### TD-1 Core engine: C# / .NET 8

- **Decision:** Event engine, execution simulator, analytics, and persistence are C# on .NET 8 (LTS), pinned via `global.json`.
- **Alternatives:** C++20; Rust.
- **Pros:** Mature toolchain; strict build (warnings-as-errors, nullable, InvariantGlobalization); `decimal` (28 digits) gives exact financial math without a bignum dependency; first-class Windows integration; large ecosystem; fast debug/verify cycles.
- **Cons:** Below C++/Rust peak per-core event throughput; GC pauses possible at sustained extreme event rates unless allocation is budgeted from Phase 1.
- **Reason:** The only candidate combining near-native throughput with rapid development and first-class Windows support. A C++ core would slow Phases 1–3 for a throughput margin those phases do not need; the kernel/port seams allow hot paths to migrate later without protocol changes.
- **Consequences:** Phase 1 must budget allocations (event pooling, batch serialization). Escape hatch: hot modules may become native plugins behind the same ports.
- **Licensing:** MIT (.NET).

### TD-2 UI: Avalonia (Phase 3)

- **Decision:** Avalonia with MVVM and a dedicated chart rendering surface.
- **Alternatives:** WinUI 3; Qt; WPF; Electron.
- **Pros:** Modern XAML, real MVVM, GPU composition, MIT license, active development, Windows 10/11 target.
- **Cons:** Younger than WPF; dock/plot ecosystems smaller — mitigated by owning the chart canvas (TD-8).
- **Reason:** TradingView-grade rendering requires owning the draw surface regardless of shell; Avalonia is the cleanest MVVM composition host on Windows.
- **Consequences:** Phases 0–2 are fully headless (already proven by the CLI); the chart build lands in Phase 3.
- **Licensing:** MIT.

### TD-3 Storage: SQLite catalog + custom columnar market-data store

- **Decision:** Two stores: (1) SQLite for catalog/metadata (symbols, datasets, runs, snapshot index, plugin registry); (2) a custom append-only columnar binary format for ticks/bars behind `IMarketDataStore`/`IDataSource` (Phase 1).
- **Alternatives:** All-SQLite; DuckDB; Parquet-only; memory-mapped custom only.
- **Pros:** SQLite is battle-tested for transactional metadata with concurrent readers. The custom store uses 128-bit timestamps and decimal-as-scaled-int pricing with zero impedance mismatch, is trivially memory-mappable, and adds no external runtime.
- **Cons:** We own the custom store's code and tooling; requires a frozen on-disk spec, versioned header, and CRC blocks.
- **Reason:** No single existing store provides both transactional catalog semantics and billion-row tick scans at full precision (float-based stores violate the money-precision rules) without external runtime weight.
- **Consequences:** Phase 1 delivers the store spec plus a validation tool before the execution engine depends on it; Parquet import/export adapters arrive Phase 2.
- **Licensing:** SQLite is public domain.

### TD-4 Serialization: custom binary wire + JSON for config/reports

- **Decision:** Custom fixed-layout wire (`Backtest.Core.Wire`, implemented in Phase 0) for IPC; `System.Text.Json` for config files and report output.
- **Alternatives:** Protobuf; FlatBuffers; MessagePack; gRPC.
- **Pros:** Exact `decimal` round-trip (scaled integer encoding), no codegen, strict validation, ~200 LOC portable to any language. JSON where humans read.
- **Cons:** We own the spec; cross-language ports must maintain byte-compatibility (enforced by contract tests from Phase 2).
- **Reason:** Financial exactness on the wire is a hard requirement; existing encoders either lack native decimal or add codegen/dependency weight without solving the problem.
- **Consequences:** Wire v1 frozen via contract tests; the version field already allows v2 negotiation.

### TD-5 IPC: length-prefixed stdio / named pipes

- **Decision:** stdio for external strategy processes; named pipes for same-machine high-throughput channels; identical frame format on both.
- **Alternatives:** gRPC; shared-memory rings; raw sockets.
- **Pros:** stdio is the most portable sandbox boundary (Python, C++, Rust, Node, JVM); named pipes are fast on Windows; one codec everywhere.
- **Cons:** stdio bandwidth is below shared memory — acceptable because strategies receive filtered/aggregate events, not raw tick firehoses.
- **Reason:** Portability and sandboxability dominate at this layer.
- **Consequences:** Phase 3 implements the sandbox host process; Phase 0 ships only the frame codec. Shared-memory ring transport for tick-level strategies is a Phase 5+ revisit.

### TD-6 Testing: xUnit

- **Decision:** xUnit via `dotnet test`; architecture contract tests live in `Backtest.Core.Tests`.
- **Alternatives:** NUnit; MSTest.
- **Pros:** Default .NET choice, `[Theory]` support, fast.
- **Cons:** None material.
- **Consequences:** Determinism tests get a dedicated non-parallel collection from Phase 1.

### TD-7 CI: GitHub Actions on Windows runners

- **Decision:** One workflow: restore → build → format check → test on `windows-latest`, SDK pinned by `global.json`.
- **Alternatives:** Linux runners (wrong platform for the shipping target); other CI hosts.
- **Pros:** Validates the actual shipping platform.
- **Cons:** Windows runners are slower than Linux.
- **Consequences:** Linux/macOS dev support is a later concern; CI stays Windows-first.

### TD-8 Charting: in-repo Skia canvas (Phase 3)

- **Decision:** Custom Skia-based chart canvas in the UI project; no third-party charting library.
- **Alternatives:** ScottPlot; LiveCharts2; OxyPlot; SciChart (commercial).
- **Pros:** Full control of replay cursor, crosshair, drawing tools, and odd tick/second chart types; no licensing cliff.
- **Cons:** Real engineering cost, budgeted as the core of Phase 3.
- **Reason:** Free libraries plateau on interactive replay-grade features; commercial licensing is a hard dependency on a vendor for the product's centerpiece.
- **Consequences:** Phase 3 is chart-heavy; Phases 1–2 remain headless.
- **Licensing:** SkiaSharp is MIT.

### TD-9 Language runtimes for strategies: adapters, not embedding

- **Decision:** Every language is an adapter to the wire protocol; nothing is embedded into the core process.
  - C# in-process adapter (fast path, trusted strategies) — Phase 2.
  - Python adapter over stdio, sandboxed process — Phase 4.
  - C++/Rust adapters via a small header/crate — Phase 4+.
  - JS/TS via Node adapter — Phase 5.
  - Any external executable speaking the frame protocol — supported from Phase 3.
- **Alternatives:** Embedding CPython/JS engines in-process; binding via JNI/P-Invoke.
- **Pros:** One protocol, N languages, one contract-test suite; a crashing strategy can never take the engine down; Core has zero per-language dependencies.
- **Cons:** IPC overhead vs embedding; each adapter is a maintenance surface.
- **Reason:** The language-agnostic requirement (rule 8) and crash isolation dominate.
- **Consequences:** Each adapter ships a hello-world strategy plus contract tests in its phase.

### TD-10 Build and packaging

- **Decision:** Plain MSBuild + `dotnet` CLI. Central Package Management via `Directory.Packages.props` (added when the first NuGet dependency appears). Packaging: portable zip from Phase 3; MSIX with signing in Phase 5.
- **Alternatives:** Cake/Nuke/FAKE build scripts; Inno Setup/NSIS installers.
- **Pros:** Identical commands locally and in CI; MSIX gives native auto-update without installer-script maintenance.
- **Cons:** MSIX needs a signing certificate (Phase 5 procurement); zip lacks auto-update.
- **Reason:** Less machinery means fewer failure modes; MSIX is the modern Windows-native distribution path.
- **Consequences:** Code-signing budget/procurement is a Phase 5 prerequisite.

## Rejection table (considered and declined)

| Candidate | Rejected because |
|---|---|
| WinUI 3 | Immature desktop story, weaker MVVM tooling than Avalonia for this use case |
| Qt | C++ slowens development; LGPL/commercial licensing complexity for a closed-feature product |
| Electron | Memory footprint and GC-in-JS unsuitable for a performance product |
| gRPC | Transport machinery not needed for local IPC; no decimal; heavy codegen |
| Protobuf | No native decimal; codegen chain for marginal gain over the in-repo codec |
| All-SQLite for ticks | Row-store scans are 10–100× slower than columnar for billion-row tick replay |
| DuckDB | External OLAP runtime dependency; embedded-analytic value arrives only in Phase 4+ reporting, revisit then |
| MT4/MT5/Soft4FX/TradingView code or formats | Prohibited by development rules 1–6 |
