# BACKTEST — Strategy API (language-agnostic)

Status: Phase 0. The wire protocol (framing, handshake types, error codes, params) is **[implemented]** in `src/Backtest.Core/Wire/`; the ports exist in `src/Backtest.Core/Ports/`. Lifecycle semantics below are the Phase 2 contract for adapters.

## 1. Design law

1. **The core is NOT designed around any language.** The wire protocol is the contract; Python, C++, C#, Rust, Java, JS/TS and external executables are all equal clients (TD-9).
2. **Strategies never touch engine internals.** The only surface a strategy has is the request/callback API defined here. No shared memory, no direct state access, no back-references.
3. **Versioned:** every frame carries `wireVersion`; every handshake carries the API version set. v1 is frozen once Phase 2 ships; incompatible changes require v2 and negotiated selection.

## 2. Transport and framing

Any byte-stream transport (stdio, named pipe, TCP). Frame layout **[implemented]**:

```
[u32 length][u16 wireVersion][u8 messageType][u64 correlationId][u32 payloadLength][payload]
```

Little-endian. `length` covers the entire frame including itself. Decoders validate: minimum length, length-prefix consistency, payload-length consistency, version support. Unknown message types are reportable errors, never crashes.

## 3. Lifecycle

```
launcher                    strategy process
   │  spawn (executable+args+params via env/stdin)  │
   │ ─────────────────────────────────────────────► │
   │                     Hello(apiVersion, strategyName, caps)
   │ ◄────────────────────────────────────────────── │
   │        HelloAck(wireVersion, chosenApi, engineInfo) | Error
   │ ─────────────────────────────────────────────► │
   │   Initialize(descriptorId, params, symbolMeta) │
   │ ◄────────────────────────────────────────────── │
   │            InitializeAck | Error(code, msg)    │
   │ ─────────────────── Start ───────────────────► │
   │ ◄──────────────────── StartAck ─────────────── │
   │      ... event loop: TickEvent/BarEvent/TimerFire/OrderUpdate/
   │      PositionUpdate/AccountUpdate ──► requests: SubmitOrder,
   │      CancelOrder, SubscribeTimer ...           │
   │ ─────────────────── Stop ────────────────────► │
   │ ◄──────────── StopAck(final state digest) ──── │
   │          kill (grace period → hard kill)       │
```

Rules:
- **Initialize** delivers immutable params + instrument metadata. The strategy computes nothing market-dependent yet.
- **Start** begins event processing. Events are delivered one at a time; the next event is sent only after the previous was acknowledged (dispatch lock-step, Phase 2) — this is what makes crash-recovery and snapshots tractable.
- **Stop** requests graceful shutdown; the host escalates to kill after the configured grace period (STRATEGY_SANDBOX §6).
- A strategy that needs timers requests them (`SubscribeTimer`) — the engine owns the clock; strategies never sleep on their own.

## 4. Events delivered to strategies

MarketTick, MarketBar, TimerFire, OrderUpdate (accepted/rejected/cancelled/partial/filled), PositionUpdate (opened/modified/closed), AccountUpdate. Delivery order = global event order (EVENT_MODEL §2). Strategies receive only streams they are subscribed to (symbol/timeframe subscriptions declared at Initialize).

## 5. Requests allowed from strategies

SubmitOrder (market/limit/stop/stop-limit with optional SL/TP), CancelOrder, ModifyOrder (Phase 2), SubscribeTimer/CancelTimer, plus informational requests (account snapshot, open positions). Each request is answered with exactly one response frame carrying the request's correlationId — no fire-and-forget in v1.

## 6. State management

- The strategy owns its private state; the engine never inspects it (sandbox boundary).
- For snapshot/branch support (SNAPSHOT_SYSTEM §4), a strategy must implement two optional messages: `ExportState` → opaque byte blob, `ImportState(blob)` → ack. Strategies that don't implement them can still run but can't participate in mid-run snapshots (recorded as a run capability flag).
- Parameter management: params are strings passed at Initialize; typed parsing is the strategy's responsibility; the UI provides schema metadata (Phase 3+ optimization needs a param schema declaration message — Phase 5).

## 7. Error handling

- Wire-level failures → `Error` frame with code **[codes implemented]**: MalformedMessage, UnsupportedVersion, UnknownMessageType, InvalidParameter, NotAllowedInState, InternalError, Timeout.
- Strategy-logic exceptions: the adapter catches, reports `Error(InternalError)`, and the host policy decides (log-and-continue, skip-strategy, or fail-run) — configured per run.
- Heartbeats: Ping/Pong **[implemented]** with configurable timeout; a missed deadline is a crash per sandbox policy.

## 8. API version registry

| Version | Status | Notes |
|---|---|---|
| wire 1 / api 1 | **Phase 0 defined; frozen at Phase 2 GA** | This document |
| api 2 | not planned yet | Breaking changes only via negotiation |

Contract tests (TESTING_STRATEGY §Contract) pin: frame round-trip, handshake sequence, error codes, param escaping, event ordering, and state export/import round-trip — per language adapter.
