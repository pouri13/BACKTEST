# BACKTEST — System Architecture

Status: Phase 0 (foundation). This document defines module boundaries, dependency rules, and the flows every future engine must follow. Code contracts that already exist in Phase 0 are marked **[implemented]**.

## 1. The prime directive

> **THE CORE MUST NOT DEPEND ON THE UI.**

The core is a headless library usable from a console, a test, a CI job, or a future GUI. This is enforced, not aspirational:

- `Backtest.Core` references no UI framework and no Windows-specific API.
- Phase 0 already ships a headless host (`Backtest.Cli`) exercising the full core — see `src/Backtest.Cli`.
- A CI check will fail (from Phase 1) if any Core project gains a UI dependency.

## 2. Layered view

```
┌───────────────────────────────────────────────────────────┐
│  UI (Phase 3): Avalonia views, chart canvas, panels       │
│    ViewModels only — zero domain logic                    │
├───────────────────────────────────────────────────────────┤
│  Application Layer                                        │
│    Use-cases/orchestration: RunBacktest, ReplaySession,   │
│    ImportDataset, SaveSnapshot, GenerateReport            │
│    (same use-cases serve CLI, GUI, tests, plugins)        │
├───────────────────────────────────────────────────────────┤
│  Domain / Core  (Backtest.Core)                           │
│    Primitives · Events · Engine · Ports · Determinism ·   │
│    Time · Wire  — no UI, no OS, no network deps           │
├───────────────────────────────────────────────────────────┤
│  Infrastructure (Phase 1+)                                │
│    Market-data store · SQLite catalog · downloaders ·     │
│    file import/export · sandbox host · telemetry sinks    │
└───────────────────────────────────────────────────────────┘
        dependencies point downward only
```

Rules:

1. A layer may reference only layers below it.
2. Core knows nothing about Application, UI, or Infrastructure types; it defines **ports** (interfaces) that Infrastructure implements.
3. The Application layer composes use-cases from Core engines + Infrastructure adapters (dependency inversion at the Core boundary).
4. UI is a consumer of Application-layer results/events. It never touches engines directly.

## 3. Modules

Phase 0 evaluated the module list from the Phase 0 brief and adjusted it: engines that share one lifecycle (order/execution/position/account) are grouped into a **Broker Simulator** subsystem with internal seams, and a **Portfolio Engine** is deferred because it is a thin aggregation over accounts until multi-account demand appears (Phase 4).

| Module | Layer | Responsibility | Depends on | Status |
|---|---|---|---|---|
| Primitives | Core | Money, Price, Quantity, rounding rules | — | **[implemented]** |
| Time | Core | SimClock, later sessions/holidays | Primitives | **[SimClock implemented]** |
| Determinism | Core | SeededRandom (SplitMix64), seeds in configs | — | **[implemented]** |
| Events | Core | Envelope, kinds, queue, ordering ranks | Time | **[implemented]** |
| Engine | Core | SimulationKernel: queue, clock advance, trace | Events, Determinism | **[implemented]** |
| Wire | Core | Frame codec + params for Strategy API | — | **[implemented]** |
| Ports | Core | Interfaces engines/hosts implement | Events | **[strategy ports]** |
| Market Data Engine | Core | Unified tick/bar stream, alignment, bars | Events, Time | Phase 1 |
| Historical Data Manager | Infra | Import, catalog, validation, versioning | Core, SQLite | Phase 1 |
| Order/Execution/Position/Account (Broker Simulator) | Core | Order lifecycle → fills → positions → account | Events, Primitives | Phase 2 |
| Risk Engine | Core | Margin checks, exposure limits | Broker Simulator | Phase 2 |
| Strategy Runtime | Core | Host for IStrategyRuntime adapters | Ports, Wire | Phase 2 (C#), 3 (sandbox), 4 (Python) |
| Snapshot Engine | Core | Capture/restore full run state | Engine + all engines | Phase 2 |
| Replay Engine | Core | Interactive clock control over kernel | Engine | Phase 3 |
| Reporting Engine | Infra | Renders report documents | Core (run results) | Phase 4 |
| Analytics Engine | Core | Metrics over trades/equity | Primitives | Phase 4 |
| Optimization Engine | Core | Parallel run orchestration | Engine | Phase 5 |
| Plugin System | App | Discovery, loading, permissions | Application | Phase 5 |
| Persistence | Infra | SQLite + snapshot storage | Core ports | Phase 1–2 |
| Logging/Telemetry | Infra | Event-sourced logs, sinks | Core events | Phase 1 |
| Configuration | App | Config load/validate/defaults | Core | Phase 1 |
| Application Layer | App | Use-cases binding Core + Infra | Core, Infra | Phase 1 |
| UI | UI | Avalonia host, panels, chart canvas | Application | Phase 3 |

## 4. Data flow

```
market data files ──▶ Historical Data Manager ──▶ Market Data Engine
                                                        │ (time-ordered events)
                                                        ▼
                                            ┌──── SimulationKernel ────┐
                                            │  EventQueue (total order)│
                                            └──────────┬───────────────┘
                       Strategy runtimes (ports)       │ pops one event
                    ┌──────────────────────────────────┤
                    ▼                                  ▼
             Broker Simulator ──────────────▶ Event trace (append-only)
                    │                                  │
                    ▼                                  ▼
             Account state ────────────────▶ Analytics / Reporting
```

One event at a time; every state mutation is triggered by exactly one event; every state change produces exactly the events documented in EVENT_MODEL.md §3.

## 5. Event flow

- Producers push envelopes into the kernel queue; consumers are invoked by the kernel loop in total order (Timestamp → Rank → SequenceNumber).
- Same-timestamp ordering is fixed by `EventRank` **[implemented]**: market data, then timers, then simulation control, then strategy output, then risk, then order, execution, position, account, telemetry. This guarantees, e.g., that a strategy sees a tick before a timer at the same instant, and account updates after position closes.
- No consumer may push to the queue synchronously during its own dispatch (Phase 1 adds a deferred-subqueue; ordering rules unchanged).

## 6. Error flow

- Domain invariants throw immediately (argument/invariant violations are programming errors, never logged-and-ignored).
- Recoverable operational problems (bad dataset row, plugin crash, strategy timeout) become **events** (e.g. `BacktestFailed`, `RiskEvent`, wire `Error` frames) so they appear in the trace and reports like everything else.
- The kernel never swallows exceptions: a failing handler marks the run `Failed` with the reason recorded in a `BacktestFailed` event **[kernel state machine implemented]**.
- Errors carry a correlation ID back to the originating request event.

## 7. Configuration flow

- Configuration is plain JSON files validated at load into immutable config objects (Phase 1). Invalid configuration is a hard error listing every violation — never a warning.
- Config is versioned; a run records the exact config (hash + content) used, so results are reproducible.
- The seeded RNG takes its seed from config only — never from wall-clock entropy **[SeededRandom implemented]**.

## 8. Persistence flow

- Market data is **immutable once written** (rule 19): corrections create new dataset versions, never in-place edits.
- Run results and event traces are append-only artifacts referenced by run ID.
- Snapshots capture full engine state (SNAPSHOT_SYSTEM.md); restore-continue and restore-branch are the two supported recovery paths.
- The SQLite catalog holds metadata (what exists, where, which version); the binary columnar store holds the data itself (TECHNOLOGY_DECISIONS.md TD-3).

## 9. Phase 0 validation

The following is already proven by code and tests (`tests/Backtest.Core.Tests/ArchitectureValidationTests.cs`):

1. Deterministic ordering of same-timestamp events by fixed rank.
2. Insertion-order independence of the queue.
3. Clock monotonicity and UTC normalization.
4. Exact decimal money arithmetic with currency-mismatch rejection.
5. Tick/step conformance with explicit rounding rules.
6. Byte-frozen canonical trace format, culture-independent.
7. Wire frame validation (truncation, length-prefix corruption).
8. Seeded RNG reproducibility (reference vector test).
