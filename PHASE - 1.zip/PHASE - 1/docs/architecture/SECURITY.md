# BACKTEST — Security Architecture

Status: Phase 0. Defines the trust model and the boundaries future phases implement (see STRATEGY_SANDBOX.md for the sandbox mechanics).

## 1. Trust model

| Component | Trust level | Rationale |
|---|---|---|
| Core engine | Trusted (our code, our tests) | Ships signed, built from this repo with gates |
| Plugins | Semi-trusted | Declared capabilities, user-granted, audited per run |
| Strategies | **Untrusted by default** | Arbitrary code from anywhere; always out-of-process unless explicitly trusted |
| Market data | Untrusted content, trusted files | Data is validated, never executed, never deserialized into code |
| Configuration | Trusted if user-authored | Invalid config aborts; hostile config cannot escalate (parsed into strict schemas) |

## 2. Hard boundaries

1. **Process boundary:** foreign strategy code never loads into the engine process (default). The trusted C# in-process path (TD-9) exists for user-authored strategies and requires explicit opt-in per strategy, recorded in run config.
2. **Data/code separation:** market data files are parsed as data with strict schemas and bounded allocations; no dynamic code generation from data, no deserialization into executable types.
3. **Capability model:** strategies/plugins declare capabilities (file system scope, network, process creation, UI). Default deny; the user grants per strategy/plugin at attach time; grants are recorded in every run manifest produced with them.
4. **No hidden egress:** the application makes zero network connections without an explicit, user-initiated action (downloads, updates). Telemetry is opt-in, documented, and inspectable in the log (BT-SEC-006).

## 3. Resource exhaustion defense

Untrusted code and hostile data must not degrade the host:

- Strategies: Job Object limits — CPU rate, memory commit, per-event wall clock, output bandwidth (STRATEGY_SANDBOX §3). Breach = kill = policy event.
- Data import: strict field counts, bounded field sizes, import progress with cancel; corrupt/hostile files fail validation without crashing the process.
- Reports/exports: bounded output sizes; rendering untrusted strings is escaped (HTML/PDF generation in Phase 4+).
- IPC: frame length caps (protocol-level maximum enforced in decoder evolution, Phase 2), per-connection bandwidth budgets, timeout on every request.

## 4. Filesystem layout rules

| Path | Writable by |
|---|---|
| Program directory | Installer/updater only |
| User workspace (projects, layouts) | App + user |
| Data root (datasets, runs, snapshots) | App (engine + importers) |
| Strategy work dirs | The strategy (scoped), sandbox-enforced |
| Credentials (future, live feeds) | DPAPI-protected user store; never in project files, never in run artifacts |

## 5. Supply chain

- Direct dependencies minimized; each new package needs a documented justification in TECHNOLOGY_DECISIONS.md updates (quality gate).
- All packages: permissive licenses only (MIT/Apache/BSD/MS-.NET); license list maintained in docs; copyleft forbidden in shipped binaries.
- CI builds pin SDK via global.json; release builds planned reproducible (deterministic flag already set).

## 6. What is explicitly NOT security (Phase 0 honesty)

- No anti-tamper/DRM goals: this is an offline desktop tool; the license model (MIT source) does not require code protection.
- No HSM/signing infrastructure yet: code signing arrives with Phase 5 packaging (TD-10); until then binaries are built from gated source only.
- The sandbox is not a security guarantee against kernel-level attacks; it is a resource/crash/permission containment layer, documented as such.
