# BACKTEST — Snapshot System

Status: Phase 0 — architecture only. The Snapshot Engine is a Phase 2 deliverable built on the kernel state machine that exists today.

## 1. Purpose

Snapshots turn a running simulation into a resumable, branchable artifact:

```
SAVE → RESTORE → CONTINUE          (pause/resume across sessions, crash recovery)
RESTORE → BRANCH → RUN ALTERNATIVE (what-if from any past point)
```

## 2. Snapshot contents (complete state, no exceptions)

| Component | Captured |
|---|---|
| Simulation clock | Current UTC + sub-sequence counter |
| Kernel | State, next event ID, queue depth; full pending-event queue (in total order) |
| Market data | Data reference (dataset ID + version + exact byte ranges consumed), stream positions |
| Broker simulator | All orders (with state machines), all fills, all positions, account state |
| Strategy state | Per strategy: descriptor + params hash + exported state blob (STRATEGY_API §6) |
| RNG | SplitMix64 state (exact 64-bit) — not the seed; continuity of the stream |
| Execution model | Any model-internal counters (e.g. latency queues in flight) |
| Configuration | Full run config (hash + content) |
| Provenance | Engine version, Strategy API version, strategy version, dataset version, snapshot schema version |
| Trace reference | Event count + last EventId captured (branch point anchor) |

A snapshot that cannot reproduce the future exactly is rejected at capture time — e.g. a strategy that cannot export state (STRATEGY_SANDBOX §7), or an event source that is not replayable. Partial snapshots are forbidden.

## 3. Format and storage

- A snapshot is a **directory**: `snapshot.json` (manifest: versions, hashes, config, branch graph position) + per-component binary files (kernel queue, orders, positions, strategy blobs).
- Binary payloads use the same scaled-integer conventions as the wire (MONEY_MODEL); the manifest is JSON for toolability.
- Snapshots are content-addressed (hash of manifest + payloads) and stored under the run's artifact tree; they are immutable once written (rule 19 discipline applies to simulation artifacts too).
- Schema version is mandatory; old snapshots load via explicit migration code paths, never silently.

## 4. Save / restore / continue

Determinism (rule 9) is what makes this safe: the pending queue + RNG state + stream positions fully determine the future. Therefore:

- **Continue** = restore all state, resume the kernel loop. The trace continues with new EventIds allocated after the highest restored ID; the run records the (snapshot → continuation) link.
- A continued run appends to a new trace segment that references the parent segment — traces are segmented so that a branch never rewrites the parent's history.

## 5. Branching

```
run A: ...event 4,000 ──► snapshot S1 ──► ...event 9,000 (run A continues)
                              │
                              └──► branch B: restore S1, new RunId,
                                   new events 4,001… under branch B
```

- A branch is a first-class run: new RunId, config diff recorded against the parent at the snapshot point, own trace segments, own artifacts.
- Branch graphs are stored in the catalog (run → parent snapshot → parent run), enabling the UI to show the tree and reports to compare branches against the common ancestor.
- The only permitted divergence point is a snapshot. "Branch from mid-air" is not a feature.

## 6. Consistency rules

1. Snapshot capture happens between kernel events (never mid-dispatch) — the lock-step dispatch model guarantees a clean boundary.
2. Restore validates every component hash before the kernel starts; any mismatch is a hard error.
3. The restored configuration must match the current engine's supported schema — engine version skew beyond the migration policy is rejected with an explicit message.
4. Determinism tests (Phase 2): run → snapshot at N → continue to M; separately run → snapshot at N → branch → run to M with identical inputs; the two traces must be byte-identical up to the branch point and identical to a control run that never snapshotted.

## 7. Out of scope (Phase 0)

Implementation of capture/restore, manifest schema finalization, and migration tooling — all Phase 2. Snapshot architecture is recorded now because the kernel's state machine and event IDs were designed around it.
