# BACKTEST — Time Model

Status: Phase 0. SimClock **[implemented]**; sessions/holidays land in Phase 1.

## 1. The five clocks

| Name | Meaning | Source | Mutable by |
|---|---|---|---|
| **Market timestamp** | The exchange/vendor timestamp carried by a tick or bar | Data file | Nobody (immutable data, rule 19) |
| **Simulation time** | The engine's current processing instant | SimClock | Kernel loop only |
| **Wall-clock time** | Real machine time | OS | Nobody (never used for any simulation decision) |
| **Strategy processing time** | How long a strategy took to handle an event (diagnostic only) | Runtime host | Measured, never simulated as market time |
| **Execution time** | Simulated broker latency: the future instant a request is acted on | Execution model | Execution model only |

Wall-clock time must never enter a simulation decision. Strategy processing duration is recorded for diagnostics but is NOT simulated as market latency unless a latency model is explicitly configured — mixing the two would make results machine-dependent.

## 2. Normalization

- All timestamps are normalized to **UTC** on ingestion; the original offset is retained in a sidecar field for audit (`OriginalOffset`), never for logic.
- All logic, storage, indexing, and comparison use UTC. Time-zone rendering is a presentation concern (reports/UI), applied last.
- Storage: 100-ns ticks (same as `DateTimeOffset`); enough for both 1970–9999 range and microsecond exchange feeds. Nanosecond sources (Phase 5) store extra precision in a documented extension field.

## 3. DST and exchange sessions

- Sessions are expressed as **offsets from UTC session anchors**, never as local wall times — DST shifts then fall out automatically.
- Sessions/holidays are part of dataset metadata (an instrument trades according to its venue calendar), versioned with the dataset.
- Inside the engine there is no "current local date": day boundaries (daily bars, swaps, session stats) are derived from the session calendar, never from `DateTime.Now`-style queries.

## 4. Tick ordering

- A feed may deliver events at equal exchange timestamps. The engine preserves feed order using (TimestampUtc, feedSeq) during ingestion; inside the kernel the envelope's SequenceNumber preserves that relative order within the same timestamp.
- Ordering rule: **no engine component may ever observe an event whose timestamp exceeds the current simulation time.**

## 5. Out-of-order and late data

- Out-of-order input is a data-quality problem, not a simulation problem: the ingestion pipeline (Phase 1) sorts by (timestamp, feed sequence) and emits a validation report; per-rule 19 raw files are never rewritten — the sorted, validated view is a separate derived dataset version.
- Events that arrive too late to be useful (later than the configured grace window) are recorded in the validation report and dropped from the derived dataset.
- The kernel itself rejects backwards clock advancement **[implemented]** — a second line of defense, not the primary one.

## 6. Missing data

- Missing ticks/bars are detected during dataset validation (gaps report).
- Strategies are never silently fed stale prices: the market-data engine emits an explicit gap marker (documented in DATA_ARCHITECTURE.md §7) so strategies can distinguish "no movement" from "no data".
- Bar-based datasets can be built from ticks (rolling windows) or validated as-is; provenance is recorded either way.

## 7. No look-ahead bias (rule 10)

Enforced structurally, not by convention:

1. The kernel pops only events whose timestamp ≤ current simulation time (by construction — events are pushed only when known, and the queue orders by time).
2. No API exposes future data: the market-data port (`IDataSource`, Phase 1) is forward-only iteration; no seek-ahead beyond the current event.
3. The strategy context exposes `NowUtc` **[implemented]** — the simulation time — and nothing else about time.
4. Determinism tests include "no-future-knowledge" scenarios from Phase 1: run a bar-close event before the bar's constituent ticks are queued, and the engine must not see them.
