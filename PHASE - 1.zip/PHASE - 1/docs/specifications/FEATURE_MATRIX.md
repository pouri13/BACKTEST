# BACKTEST — Feature Matrix

Status: Phase 0 planning baseline. Every feature names its planned phase, architectural owner (module), dependencies, and test strategy. Owners: `MD` Market Data Engine · `HDM` Historical Data Manager · `EV` Event/Kernel · `BRK` Broker Simulator · `RISK` Risk Engine · `SR` Strategy Runtime · `SNAP` Snapshot Engine · `REPLAY` Replay Engine · `AN` Analytics/Reporting · `OPT` Optimization Engine · `CHART` Chart/Canvas · `UI` Application UI · `PLUGIN` Plugin System. "—" = no dependency beyond the owner's own prerequisites.

## Charting

| Feature | Req | Phase | Owner | Dependencies | Test strategy |
|---|---|---|---|---|---|
| Candlestick | BT-UI-002 | 3 | CHART | data pipeline | golden-image render tests; data-transform unit tests |
| OHLC bars | BT-UI-002 | 3 | CHART | candlestick | golden-image tests |
| Line | BT-UI-002 | 3 | CHART | candlestick | golden-image tests |
| Area | BT-UI-002 | 3 | CHART | line | golden-image tests |
| Heikin Ashi | BT-UI-003 | 3 | MD+CHART | OHLCV source | transform unit tests (deterministic HA math) |
| Renko | BT-UI-003 | 4 | MD+CHART | tick/bar source | brick-boundary unit tests on synthetic moves |
| Range bars | BT-UI-003 | 4 | MD+CHART | tick source | range-boundary unit tests |
| Tick chart | BT-UI-003 | 4 | MD+CHART | tick source | event-count windowing tests |
| Seconds chart | BT-UI-003 | 4 | MD+CHART | tick source | sub-minute aggregation tests |
| Custom timeframe | BT-UI-003 | 4 | MD | bar builder | arbitrary-window aggregation tests |
| Multi-chart | BT-UI-001 | 3 | UI | shell docking | workspace persistence round-trip |
| Multi-symbol | BT-BT-004 | 3 | UI+MD | multi-symbol engine | layout + data-binding tests |
| Crosshair | BT-UI-002 | 3 | CHART | canvas | hit-test unit tests (data-space) |
| Zoom | BT-UI-002 | 3 | CHART | canvas | viewport-transform property tests (no data loss at any zoom) |
| Pan | BT-UI-002 | 3 | CHART | zoom | same as zoom |
| Drawing tools | BT-UI-004 | 3–4 | CHART | canvas | serialization round-trip; hit-testing tests |
| Fibonacci tools | BT-UI-004 | 4 | CHART | drawing tools | level-math unit tests |
| Measurement tools | BT-UI-004 | 3 | CHART | crosshair | value/time delta math tests |
| Indicators | BT-UI-005 | 3–4 | AN+CHART | bar pipeline | reference-value tests vs independent implementations |
| Chart synchronization | BT-UI-012 | 4 | CHART+UI | multi-chart | group-sync event tests |
| Replay cursor | BT-REPLAY-00x | 3 | CHART+REPLAY | replay engine | cursor position == simulation time invariants |

## Trading

| Feature | Req | Phase | Owner | Dependencies | Test strategy |
|---|---|---|---|---|---|
| Market orders | BT-EXEC-001 | 2 | BRK | event engine | scenario: fill at bid/ask ± slippage, side rules |
| Limit orders | BT-EXEC-002 | 2 | BRK | market orders | scenario: buy-limit fills at limit or better, never worse |
| Stop orders | BT-EXEC-003 | 2 | BRK | limit orders | scenario: trigger on breach; gap-through fills |
| Stop-limit | BT-EXEC-004 | 2 | BRK | stop+limit | scenario: trigger then limit semantics |
| SL | BT-EXEC-005 | 2 | BRK | order types | scenario: exit respects side rules; weekend gap case |
| TP | BT-EXEC-005 | 2 | BRK | SL | scenario: exit at target or better |
| Trailing stop | BT-EXEC-006 | 2 | BRK | SL | scenario: trail distance/step monotonicity |
| Break-even | BT-EXEC-007 | 2 | BRK | SL | scenario: trigger threshold math |
| Partial close | BT-EXEC-008 | 2 | BRK | positions | scenario: quantity math exact, avg price preserved |
| Modify order | BT-EXEC-009 | 2 | BRK | working orders | scenario: price/qty/TIF modify events |
| Cancel order | BT-EXEC-009 | 2 | BRK | working orders | scenario: terminal state; no post-cancel fills |
| OCO | BT-EXEC-010 | 2 | BRK | order links | scenario: one fill cancels sibling; trace proof |
| Position sizing | BT-EXEC-011 | 2 | RISK+BRK | instrument specs | unit tests: risk% + stop distance + step conformance |
| Risk % | BT-EXEC-011 | 2 | RISK | position sizing | unit tests incl. rounding TowardZero |
| Margin | BT-EXEC-012 | 2 | BRK+RISK | account engine | scenario: init/maintenance levels, margin call events |
| Leverage | BT-EXEC-012 | 2 | BRK | margin | unit tests per instrument leverage |
| Commission | BT-EXEC-013 | 2 | BRK | fills | exact-decimal accounting tests incl. entry+exit |
| Spread | BT-EXEC-014 | 2 | BRK | bid/ask data | unit tests: spread read from data, not assumed |
| Swap | BT-EXEC-015 | 2 | BRK | session calendar | scenario: daily accrual + triple-day rules |
| Slippage | BT-EXEC-016 | 2 | BRK | seeded RNG | property tests: bounded, deterministic, side-correct |
| Latency | BT-EXEC-017 | 2 | BRK | timer events | scenario: delayed fills provable in trace |
| Partial fills | BT-EXEC-018 | 2 | BRK | volume model | scenario: volume-capped remainders |

## Replay

| Feature | Req | Phase | Owner | Dependencies | Test strategy |
|---|---|---|---|---|---|
| Play | BT-REPLAY-001 | 3 | REPLAY | kernel state machine | state-machine tests |
| Pause / Resume | BT-REPLAY-001 | 3 | REPLAY | play | determinism after pause/resume cycle |
| Step tick | BT-REPLAY-002 | 3 | REPLAY | pause | single-event advance == trace prefix |
| Step bar | BT-REPLAY-002 | 3 | REPLAY | pause | bar-boundary advance |
| Forward | BT-REPLAY-004 | 3 | REPLAY | snapshots | seek lands on snapshot, continues deterministically |
| Rewind | BT-REPLAY-004 | 3 | REPLAY+SNAP | snapshots | restore+truncate semantics |
| Variable speed | BT-REPLAY-003 | 3 | REPLAY | play | pacing curve tests (0.1×–1000×) |
| Session control | BT-REPLAY-005 | 3 | REPLAY+MD | calendars | boundary jump tests on DST sample data |
| Save simulation | BT-REPLAY-006 | 2 | SNAP | kernel state | snapshot round-trip determinism |
| Restore simulation | BT-REPLAY-006 | 2 | SNAP | save | continue-to-M equality with control run |

## Backtesting

| Feature | Req | Phase | Owner | Dependencies | Test strategy |
|---|---|---|---|---|---|
| Tick based | BT-BT-001 | 2 | EV+MD | data pipeline | 1:1 tick delivery proof in trace |
| Event driven | BT-BT-003 | 0→2 | EV | kernel | all state changes event-caused (audit) |
| Bar based | BT-BT-002 | 2 | MD | bar datasets | equivalence vs tick-derived bars |
| Multi-symbol | BT-BT-004 | 2 | EV+MD | k-way merge | ordering tests across 10 symbols |
| Multi-timeframe | BT-BT-005 | 2 | MD | calendars | M1/H1 alignment tests |
| Portfolio | BT-BT-006 | 4 | BRK | multi-symbol | combined equity/exposure tests |
| Realistic execution | BT-EXEC-001..006 | 2 | BRK | execution models | scenario suite per model switch |
| Deterministic runs | BT-CORE-002 | 0→cont. | EV | seed, clock | byte-equal traces; cross-machine |
| Reproducibility | BT-BT-008 | 2 | SNAP+EV | determinism | snapshot/branch equality |
| No look-ahead bias | BT-CORE-003 | 0→cont. | EV+MD | forward-only source | no-future-knowledge scenario tests |
| Data validation | BT-BT-009 | 1 | HDM | validation rules | reject-unvalidated-dataset test |

## Strategy Runtime

| Feature | Req | Phase | Owner | Dependencies | Test strategy |
|---|---|---|---|---|---|
| Python | BT-STRAT-003 | 4 | SR | sandbox host | hello-strategy contract tests over stdio |
| C++ | BT-STRAT-004 | 4+ | SR | wire header | adapter contract tests |
| C# | BT-STRAT-002 | 2 | SR | wire ports | in-process contract tests |
| Rust | BT-STRAT-004 | 4+ | SR | wire crate | adapter contract tests |
| Java | BT-STRAT-004 | future | SR | wire JAR | adapter contract tests |
| JavaScript/TypeScript | BT-STRAT-005 | 5 | SR | node adapter | contract tests over stdio |
| External executable | BT-STRAT-006 | 3 | SR | launcher | generic-process contract tests |
| Plugin adapters | BT-PLUGIN-003 | 5 | PLUGIN+SR | plugin system | sample adapter plugin |
| IPC | BT-STRAT-001 | 0→2 | SR | wire codec | frame/lock-step dispatch tests |
| API versioning | BT-STRAT-010 | 0→cont. | SR | handshake | negotiation + rejection tests |
| Sandbox/isolation | BT-SEC-001..004 | 3 | SR | job objects | crash-injection; limit-breach tests |

## Debugging

| Feature | Req | Phase | Owner | Dependencies | Test strategy |
|---|---|---|---|---|---|
| Event log | BT-DBG-001 | 0→2 | EV | canonical trace | replay-to-identical-state test |
| Tick log | BT-DBG-002 | 2 | EV+MD | event log | per-tick completeness |
| Signal log | BT-DBG-003 | 2 | SR | StrategySignal | query + filter tests |
| Decision log | BT-DBG-003 | 2 | BRK+SR | engine decisions | decision trace completeness |
| Order log | BT-DBG-004 | 2 | BRK | order events | lifecycle reconstruction per order |
| Position log | BT-DBG-004 | 2 | BRK | position events | lifecycle reconstruction per position |
| Variable inspection | BT-DBG-005 | 3 | SR+UI | state export | read-only state renderer tests |
| Breakpoints | BT-DBG-006 | 3 | REPLAY | step/pause | exact-event-id pause tests |
| Strategy state | BT-DBG-007 | 2 | SR | export/import | blob round-trip |
| Snapshots | BT-SNAP-001 | 2 | SNAP | kernel | see Snapshot tests |
| Branching | BT-SNAP-002 | 2→3 | SNAP | snapshots | branch graph tests |
| Replay from snapshot | BT-DBG-008 | 3 | REPLAY+SNAP | restore | mid-run restore == control run |

## Data

| Feature | Req | Phase | Owner | Dependencies | Test strategy |
|---|---|---|---|---|---|
| Historical download | BT-DATA-013 | 2 | HDM | venue adapters | sample venue end-to-end import+validate |
| Tick data | BT-DATA-001 | 1 | HDM+MD | store | 1M-tick import/replay; CRC checks |
| OHLC | BT-DATA-002 | 1 | HDM | store | multi-TF coexistence |
| CSV import | BT-DATA-006 | 1 | HDM | pipeline | strict-schema streaming tests |
| JSON import | BT-DATA-007 | 1 | HDM | CSV pipeline | schema tests |
| Parquet | BT-DATA-008 | 2 | HDM | interchange | round-trip fidelity on scaled ints |
| Custom format | BT-DATA-009 | 5 | PLUGIN | IDataSource | sample plugin format |
| Data validation | BT-DATA-004 | 1 | HDM | rules §6 | each rule has a violation fixture |
| Data normalization | BT-DATA-004 | 1 | HDM | validation | sorted-derivation preserves bytes |
| Data indexing | BT-DATA-010 | 1 | HDM | segments | O(log n) seek tests |
| Data compression | BT-DATA-011 | 1 | HDM | segments | ratio ≥2×; integrity after decompress |
| Data versioning | BT-DATA-012 | 1 | HDM | immutability | correction creates v+1; raw unchanged |
| Data source plugins | BT-DATA-009 | 5 | PLUGIN | plugin system | custom-format sample |

## Analytics

| Feature | Req | Phase | Owner | Dependencies | Test strategy |
|---|---|---|---|---|---|
| Equity curve | BT-RPT-002 | 4 | AN | trade/trace data | per-event equity vs manual reference |
| Drawdown | BT-RPT-003 | 4 | AN | equity curve | max-DD property tests (peak-to-trough) |
| Sharpe | BT-RPT-003 | 4 | AN | returns | reference-value tests (known inputs) |
| Sortino | BT-RPT-003 | 4 | AN | returns | reference-value tests |
| Profit factor | BT-RPT-003 | 4 | AN | trade list | gross win/loss ratio tests |
| Expectancy | BT-RPT-003 | 4 | AN | trade list | formula tests incl. zero-trade edge |
| Win rate | BT-RPT-003 | 4 | AN | trade list | boundary tests (scratch trades) |
| Risk metrics (VaR/CVaR, exposure) | BT-RPT-003 | 4 | AN | returns | reference implementations |
| Monthly statistics | BT-RPT-004 | 4 | AN | trade list | calendar-month grouping (UTC) |
| Daily statistics | BT-RPT-004 | 4 | AN | trade list | session-day grouping (not calendar-day) |
| Symbol statistics | BT-RPT-004 | 4 | AN | trade list | per-symbol attribution |
| Session statistics | BT-RPT-004 | 4 | AN | calendars | per-session grouping |
| Trade distribution | BT-RPT-003 | 4 | AN | trade list | histogram bucketing tests |

## Optimization

| Feature | Req | Phase | Owner | Dependencies | Test strategy |
|---|---|---|---|---|---|
| Grid search | BT-OPT-001 | 5 | OPT | parallel runner | worker-count invariance (results identical) |
| Random search | BT-OPT-002 | 5 | OPT | seeded RNG | reproducible sampling sequence |
| Genetic optimization | BT-OPT-003 | 5 | OPT | random search | seeded generation tests |
| Walk-forward | BT-OPT-004 | 5 | OPT | grid/random | window boundary tests; OOS aggregation |
| Monte Carlo | BT-OPT-005 | 5 | OPT+AN | trade list | seeded reshuffling reproducibility |
| Parameter sweeps | BT-OPT-006 | 5 | OPT | grid search | sweep completeness (no skipped combos) |
| Parallel execution | BT-OPT-007 | 5 | OPT | run isolation | determinism under concurrency tests |

## Coverage notes

- Every feature above traces to at least one requirement in PRODUCT_REQUIREMENTS.md; every "Must" requirement traces to at least one feature.
- Phase 0 has deliberately no features marked implemented beyond the contracts listed in SYSTEM_ARCHITECTURE §9 — the matrix is a plan, not a status report. Status tracking happens per-phase in docs/phases/PHASE_N_REPORT.md.
