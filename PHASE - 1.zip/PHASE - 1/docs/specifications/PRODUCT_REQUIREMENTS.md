# BACKTEST — Product Requirements

Status: Phase 0 baseline. Requirements are living but numbered permanently; removed/never-built requirements are marked as such, never deleted silently (development rule 12).

## Vision

A professional, Windows-native trading simulation and backtesting platform — market replay, algorithmic strategy testing, and strategy debugging with realistic broker simulation — fully independent of MetaTrader, MT4/MT5, TradingView, and Soft4FX. Soft4FX-style replay/simulator capability is the *baseline*, not the ceiling: the product targets tick-level, event-driven, multi-symbol, multi-timeframe backtesting with deterministic, snapshotable runs.

## Requirement fields

Every requirement carries: **ID** (BT-<AREA>-NNN), **Description**, **Priority** (Must / Should / Could), **Phase** (target delivery), **Dependencies**, **Acceptance criteria** (testable).

## 1. Core requirements

| ID | Description | Priority | Phase | Dependencies | Acceptance criteria |
|---|---|---|---|---|---|
| BT-CORE-001 | Headless core usable without UI | Must | 0 | — | CLI runs full core; Core project has no UI/OS-specific deps |
| BT-CORE-002 | Deterministic simulation: same config+data+seed ⇒ byte-identical traces | Must | 0→continuous | BT-CORE-001 | Determinism tests pass on repeat runs and across machines |
| BT-CORE-003 | No look-ahead bias | Must | 0→continuous | BT-CORE-002 | Kernel cannot observe events beyond sim time; Phase 1 no-future tests |
| BT-CORE-004 | Exact financial arithmetic (decimal, explicit rounding) | Must | 0 | — | MONEY_MODEL rules pinned by tests; no float in money path |
| BT-CORE-005 | Event-driven architecture with total event ordering | Must | 0 | BT-CORE-002 | Same-timestamp rank ordering test; insertion-order independence test |
| BT-CORE-006 | Simulation clock strictly monotonic, UTC | Must | 0 | — | Clock tests (backwards rejected, UTC-normalized) |
| BT-CORE-007 | Configuration load/validate with hard failure on invalid config | Must | 1 | BT-CORE-001 | Invalid config lists all violations and aborts |
| BT-CORE-008 | Run provenance: every run records config hash, data versions, engine version | Must | 1 | BT-CORE-007 | Two runs with different inputs are never confused in reports |
| BT-CORE-009 | Plugin architecture for extensions | Should | 5 | BT-STRAT-001 | Plugin discovery/permission model demoed with a sample plugin |

## 2. Backtesting requirements

| ID | Description | Priority | Phase | Dependencies | Acceptance criteria |
|---|---|---|---|---|---|
| BT-BT-001 | Tick-based backtesting | Must | 2 | BT-DATA-001..003 | Strategy receives every tick; trace proves 1:1 |
| BT-BT-002 | Bar-based backtesting | Must | 2 | BT-DATA-002 | Runs on OHLCV datasets; same results as tick→bar derivation within documented tolerance |
| BT-BT-003 | Event-driven engine (no polling loops) | Must | 0 (kernel) → 2 (engines) | BT-CORE-005 | All state changes are event-caused; audit via trace |
| BT-BT-004 | Multi-symbol backtesting | Must | 2 | BT-BT-001 | 10 symbols replay in one run with correct cross-symbol ordering |
| BT-BT-005 | Multi-timeframe backtesting | Must | 2 | BT-BT-004 | Strategy receives M1+H1 bars consistently aligned |
| BT-BT-006 | Portfolio backtesting across symbols | Should | 4 | BT-BT-004 | Cross-symbol exposure and combined equity reported |
| BT-BT-007 | Realistic execution in backtest | Must | 2 | BT-EXEC-001..006 | Fill model matches configured spread/slippage/latency in scenario tests |
| BT-BT-008 | Reproducibility of runs | Must | 0→continuous | BT-CORE-002 | Snapshot/branch tests; cross-machine trace equality |
| BT-BT-009 | Data validation before run | Must | 1 | BT-DATA-004 | Runs refuse unvalidated datasets |

## 3. Market replay requirements

| ID | Description | Priority | Phase | Dependencies | Acceptance criteria |
|---|---|---|---|---|---|
| BT-REPLAY-001 | Play/pause/resume replay | Must | 3 | BT-BT-003 | Transport controls drive kernel state machine |
| BT-REPLAY-002 | Step tick / step bar | Must | 3 | BT-REPLAY-001 | Single-event advance verified against trace |
| BT-REPLAY-003 | Variable replay speed | Must | 3 | BT-REPLAY-001 | Speed factors 0.1×–1000× deliver correct event pacing |
| BT-REPLAY-004 | Jump forward/backward (seek) | Must | 3 | BT-SNAP-001 | Seek uses snapshots, not re-simulation from zero |
| BT-REPLAY-005 | Session control (jump to session start/end) | Should | 3 | BT-DATA-005 | Calendar-aware jumps land on session boundaries |
| BT-REPLAY-006 | Save/restore simulation state | Must | 2 (engine), 3 (UI) | BT-SNAP-001 | Snapshot round-trip preserves future determinism |
| BT-REPLAY-007 | Branching replay from any snapshot | Must | 3 | BT-SNAP-002 | Branch runs recorded in branch graph |

## 4. Trading/execution requirements

| ID | Description | Priority | Phase | Dependencies | Acceptance criteria |
|---|---|---|---|---|---|
| BT-EXEC-001 | Market orders | Must | 2 | BT-BT-003 | Immediate fill at prevailing bid/ask ± slippage |
| BT-EXEC-002 | Limit orders | Must | 2 | BT-EXEC-001 | Fill rules per side documented and scenario-tested |
| BT-EXEC-003 | Stop orders | Must | 2 | BT-EXEC-002 | Trigger on touch/breach per configured rule |
| BT-EXEC-004 | Stop-limit orders | Must | 2 | BT-EXEC-003 | Two-stage trigger/fill semantics tested |
| BT-EXEC-005 | SL / TP attached to positions | Must | 2 | BT-EXEC-001 | Exit fills respect side rules and session gaps |
| BT-EXEC-006 | Trailing stop | Must | 2 | BT-EXEC-005 | Trail distance/step rules scenario-tested |
| BT-EXEC-007 | Break-even automation | Should | 2 | BT-EXEC-005 | BE move triggers at configured profit threshold |
| BT-EXEC-008 | Partial close | Must | 2 | BT-EXEC-005 | Position quantity reduces; avg price logic tested |
| BT-EXEC-009 | Modify/cancel working orders | Must | 2 | BT-EXEC-002 | Modify events recorded; cancelled orders terminal |
| BT-EXEC-010 | OCO orders | Must | 2 | BT-EXEC-002 | One fill cancels the sibling; trace proves it |
| BT-EXEC-011 | Risk-based position sizing | Must | 2 | BT-EXEC-001 | Size computed from stop distance + risk % + instrument specs |
| BT-EXEC-012 | Margin & leverage simulation | Must | 2 | BT-EXEC-001 | Margin calls fire at configured levels; rejected orders logged |
| BT-EXEC-013 | Commission models | Must | 2 | BT-EXEC-001 | Per-lot/per-trade models; entry+exit accounting exact |
| BT-EXEC-014 | Spread simulation | Must | 2 | BT-DATA-001 | Fills cross bid/ask correctly on tick data |
| BT-EXEC-015 | Swap/financing accrual | Must | 2 | BT-DATA-005 | Session-calendar accrual incl. triple-day rules |
| BT-EXEC-016 | Slippage models | Must | 2 | BT-EXEC-001 | Fixed/variable/distribution models; seeded RNG only |
| BT-EXEC-017 | Latency simulation | Should | 2 | BT-EXEC-001 | Delayed fill timestamps provable in trace |
| BT-EXEC-018 | Partial fills | Should | 2 | BT-EXEC-001 | Volume-capped fills; order lifecycle handles remainders |
| BT-EXEC-019 | Order rejections | Must | 2 | BT-EXEC-012 | Margin/market-closed/invalid-price rejections as events |
| BT-EXEC-020 | Market closure handling | Must | 2 | BT-DATA-005 | Configurable queue-or-reject; never fill outside sessions |

## 5. Historical data requirements

| ID | Description | Priority | Phase | Dependencies | Acceptance criteria |
|---|---|---|---|---|---|
| BT-DATA-001 | Tick data ingestion (quotes, later trades) | Must | 1 | — | 1M-tick dataset imports, validates, replays |
| BT-DATA-002 | OHLCV ingestion any timeframe | Must | 1 | — | Multi-TF datasets coexist per symbol |
| BT-DATA-003 | Bid/ask + spread storage | Must | 1 | BT-DATA-001 | Spread computed exactly from stored columns |
| BT-DATA-004 | Validation pipeline | Must | 1 | BT-DATA-001 | Six validation rules of DATA_ARCHITECTURE §6 enforced |
| BT-DATA-005 | Session/holiday calendars per venue | Must | 1 | — | DST-correct session math on sample venues |
| BT-DATA-006 | CSV import | Must | 1 | BT-DATA-001 | Strict schema, streaming, cancelable |
| BT-DATA-007 | JSON import | Should | 1 | BT-DATA-006 | Same pipeline, JSON schema |
| BT-DATA-008 | Parquet import/export | Should | 2 | BT-DATA-006 | Round-trip fidelity proven on scaled-int columns |
| BT-DATA-009 | Custom format plugins | Could | 5 | BT-CORE-009 | Third-party format loads via IDataSource |
| BT-DATA-010 | Indexing & time-range seek | Must | 1 | BT-DATA-001 | Mid-dataset seek via sparse index, O(log n) |
| BT-DATA-011 | Compression | Should | 1 | BT-DATA-001 | Block compression ≥2× on typical tick data |
| BT-DATA-012 | Dataset versioning (immutable) | Must | 1 | BT-DATA-004 | Corrections create v+1; raw bytes never change |
| BT-DATA-013 | Historical downloader (venues/providers) | Must | 2 | BT-DATA-001 | Sample venue adapter downloads + validates end-to-end |

## 6. Strategy runtime requirements

| ID | Description | Priority | Phase | Dependencies | Acceptance criteria |
|---|---|---|---|---|---|
| BT-STRAT-001 | Language-agnostic Strategy API (wire protocol) | Must | 0 (wire) → 2 (runtime) | — | Framing/handshake pinned by contract tests |
| BT-STRAT-002 | C# in-process runtime | Must | 2 | BT-STRAT-001 | Sample strategy passes full event/contract suite |
| BT-STRAT-003 | Python runtime (external process) | Should | 4 | BT-STRAT-001, BT-SANDBOX-001 | Hello-strategy passes contract tests over stdio |
| BT-STRAT-004 | C++/Rust runtimes | Could | 4+ | BT-STRAT-001 | Header/crate + hello-strategy contract tests |
| BT-STRAT-005 | JS/TS runtime | Could | 5 | BT-STRAT-001 | Node adapter passes contract tests |
| BT-STRAT-006 | Any external executable speaking the protocol | Should | 3 | BT-STRAT-001 | Generic launcher runs an arbitrary sample process |
| BT-STRAT-007 | Strategy parameter management | Must | 2 | BT-STRAT-002 | Params delivered at init; schema metadata for UI (Phase 3+) |
| BT-STRAT-008 | Strategy state export/import for snapshots | Must | 2 | BT-STRAT-002, BT-SNAP-001 | Export/import round-trip preserves run determinism |
| BT-STRAT-009 | Strategy versioning recorded per run | Must | 2 | BT-CORE-008 | Run manifest includes strategy identity+version |
| BT-STRAT-010 | API versioning with backward compatibility | Must | 0→continuous | BT-STRAT-001 | v1 frozen at Phase 2 GA; negotiation tested |

## 7. Debugging requirements

| ID | Description | Priority | Phase | Dependencies | Acceptance criteria |
|---|---|---|---|---|---|
| BT-DBG-001 | Full event log (replayable trace) | Must | 0 (canonical trace) → 2 (persistent) | BT-CORE-005 | Trace replays to identical state |
| BT-DBG-002 | Tick-by-tick logging | Must | 2 | BT-DBG-001 | Per-tick records with market + engine context |
| BT-DBG-003 | Signal & decision logging | Must | 2 | BT-STRAT-002 | StrategySignal + engine decisions queryable |
| BT-DBG-004 | Order/position logs | Must | 2 | BT-EXEC-001 | Full lifecycle per order/position from trace |
| BT-DBG-005 | Variable inspection (strategy state view) | Should | 3 | BT-STRAT-008 | Exported state rendered read-only in UI |
| BT-DBG-006 | Breakpoints (event/time/condition) | Should | 3 | BT-REPLAY-002 | Pauses at exact event ID; state inspectable |
| BT-DBG-007 | Strategy state snapshots | Must | 2 | BT-SNAP-001 | State blob round-trips |
| BT-DBG-008 | Replay from snapshot | Must | 3 | BT-SNAP-001 | Debug session restores mid-run state |
| BT-DBG-009 | Branching from debug session | Should | 3 | BT-SNAP-002 | Alternative scenario run from breakpoint |

## 8. Reporting requirements

| ID | Description | Priority | Phase | Dependencies | Acceptance criteria |
|---|---|---|---|---|---|
| BT-RPT-001 | Trade list with full economics | Must | 4 | BT-EXEC-013 | Every trade: fills, commission, swap, P&L, duration |
| BT-RPT-002 | Equity/balance curve | Must | 4 | BT-RPT-001 | Per-event equity from trace; exportable |
| BT-RPT-003 | Summary metrics suite (see FEATURE_MATRIX Analytics) | Must | 4 | BT-RPT-001 | Values match independent reference calculations |
| BT-RPT-004 | Monthly/daily/symbol/session statistics | Must | 4 | BT-RPT-003 | Groupings verified against trade list |
| BT-RPT-005 | CSV/JSON export | Must | 4 | BT-RPT-001 | Machine-readable, schema-versioned |
| BT-RPT-006 | Excel export | Should | 4 | BT-RPT-005 | Opens cleanly; numbers not text |
| BT-RPT-007 | HTML report | Should | 4 | BT-RPT-003 | Self-contained file, charts included |
| BT-RPT-008 | PDF report | Could | 5 | BT-RPT-007 | Deterministic layout from same data |

## 9. Optimization requirements

| ID | Description | Priority | Phase | Dependencies | Acceptance criteria |
|---|---|---|---|---|---|
| BT-OPT-001 | Grid search | Must | 5 | BT-BT-008 | Deterministic across parallel workers |
| BT-OPT-002 | Random search | Should | 5 | BT-OPT-001 | Seeded, documented sampling |
| BT-OPT-003 | Genetic optimizer | Could | 5 | BT-OPT-002 | Seeded evolution, reproducible generations |
| BT-OPT-004 | Walk-forward analysis | Must | 5 | BT-OPT-001 | Anchored/rolling windows with OOS aggregation |
| BT-OPT-005 | Monte Carlo analysis | Should | 5 | BT-RPT-001 | Trade reshuffling/resampling; seeded |
| BT-OPT-006 | Parameter sweep visualization | Should | 5 | BT-OPT-001 | Heatmap of objective vs params |
| BT-OPT-007 | Parallel execution | Must | 5 | BT-OPT-001 | N workers ≥ 4× speedup on 8 cores for pure-CPU runs |

## 10. UI requirements

| ID | Description | Priority | Phase | Dependencies | Acceptance criteria |
|---|---|---|---|---|---|
| BT-UI-001 | Main shell with docking workspaces | Must | 3 | BT-CORE-001 | Layout persists; all panels dock/float/tab |
| BT-UI-002 | Chart panel (candle/bar/line/area first) | Must | 3 | BT-UI-001 | 60 fps pan/zoom on ≥100k visible bars (target hardware class) |
| BT-UI-003 | Derived chart types (Heikin Ashi/Renko/Range/tick/seconds) | Should | 3–4 | BT-UI-002 | Rendered via data transforms; correctness tests at data layer |
| BT-UI-004 | Drawing tools incl. Fibonacci + measurement | Should | 3–4 | BT-UI-002 | Persist per workspace+symbol+timeframe |
| BT-UI-005 | Indicators on chart | Should | 3–4 | BT-UI-002 | At least MA/EMA/RSI/ATR/Bollinger |
| BT-UI-006 | Replay transport UI (play/pause/step/speed) | Must | 3 | BT-REPLAY-001..003 | Controls mirror engine state exactly |
| BT-UI-007 | Order/positions/account panels | Must | 3 | BT-EXEC-001+ | Live state from event stream; actions hit use-cases only |
| BT-UI-008 | Watchlist | Must | 3 | BT-UI-001 | Multi-symbol quotes with spread |
| BT-UI-009 | Strategy panel (attach/configure/start/stop) | Must | 3 | BT-STRAT-002 | Param editing validated against schema |
| BT-UI-010 | Debug panel (trace inspection, breakpoints) | Should | 3 | BT-DBG-006 | Event-level navigation with state view |
| BT-UI-011 | Timeline with markers | Should | 3 | BT-SNAP-001 | Snapshot/branch/trade markers clickable |
| BT-UI-012 | Multi-chart sync (crosshair/zoom groups) | Could | 4 | BT-UI-002 | Group sync toggles per layout |
| BT-UI-013 | Settings + workspace/project management | Must | 3 | BT-UI-001 | Workspaces saved/restored losslessly |

## 11. Plugin requirements

| ID | Description | Priority | Phase | Dependencies | Acceptance criteria |
|---|---|---|---|---|---|
| BT-PLUGIN-001 | Plugin discovery & manifest | Must | 5 | BT-CORE-009 | Manifest validation; versioned host interfaces |
| BT-PLUGIN-002 | Permission model for plugins | Must | 5 | BT-PLUGIN-001 | Capabilities declared, granted, audited per run |
| BT-PLUGIN-003 | Data-source plugins | Should | 5 | BT-PLUGIN-001, BT-DATA-009 | Sample plugin imports a custom format |
| BT-PLUGIN-004 | Report-export plugins | Could | 5 | BT-PLUGIN-001 | Sample plugin adds export format |

## 12. Security requirements

| ID | Description | Priority | Phase | Dependencies | Acceptance criteria |
|---|---|---|---|---|---|
| BT-SEC-001 | Strategy process isolation | Must | 3 | BT-STRAT-001 | Foreign code never loads into engine process (see SECURITY.md) |
| BT-SEC-002 | Strategy sandbox resource limits | Must | 3 | BT-SEC-001 | CPU/mem/time limits enforced via Job Objects; breach kills process |
| BT-SEC-003 | Default-deny network for strategies | Must | 3 | BT-SEC-001 | Grant requires explicit user action; recorded per run |
| BT-SEC-004 | Filesystem confinement for strategies | Must | 3 | BT-SEC-001 | Strategy sees only its work directory |
| BT-SEC-005 | Plugin signing/verification | Could | 5 | BT-PLUGIN-001 | Unsigned plugins require explicit override |
| BT-SEC-006 | No telemetry without consent | Must | 1 | — | Zero outbound connections by default; documented |

## 13. Performance requirements

| ID | Description | Priority | Phase | Dependencies | Acceptance criteria |
|---|---|---|---|---|---|
| BT-PERF-001 | Tick replay ≥5M events/s single core (no strategy) | Must | 2 | BT-DATA-010 | Benchmark meets floor on CI hardware class |
| BT-PERF-002 | ≥1M events/s with in-process strategy | Must | 2 | BT-PERF-001 | Benchmark meets floor |
| BT-PERF-003 | Billion-event datasets stream without OOM | Must | 2 | BT-DATA-001 | 1B-row synthetic dataset replay at constant memory |
| BT-PERF-004 | Optimization parallel scaling | Should | 5 | BT-OPT-007 | See BT-OPT-007 |
| BT-PERF-005 | Chart interactions ≥60 fps at 100k bars | Should | 3 | BT-UI-002 | Frame-time benchmark |

## 14. Reliability requirements

| ID | Description | Priority | Phase | Dependencies | Acceptance criteria |
|---|---|---|---|---|---|
| BT-REL-001 | Crash recovery via snapshots | Must | 2 | BT-SNAP-001 | Kill mid-run, restore, continue to identical result |
| BT-REL-002 | Strategy crash isolation | Must | 3 | BT-SEC-001 | Killed strategy → policy event, engine survives |
| BT-REL-003 | Corrupt dataset detection | Must | 1 | BT-DATA-004 | CRC mismatch rejects dataset at load |
| BT-REL-004 | Invalid config never starts a run | Must | 1 | BT-CORE-007 | Hard failure with complete violation list |
| BT-REL-005 | Deterministic re-run after any failure | Must | 2→continuous | BT-CORE-002 | Failed run re-executes byte-identically |
| BT-REL-006 | Graceful shutdown preserves artifacts | Should | 2 | BT-SNAP-001 | SIGINT/close produces consistent snapshot or clean abort |

## 15. Future/optional requirements

| ID | Description | Priority | Phase | Dependencies | Acceptance criteria |
|---|---|---|---|---|---|
| BT-FUT-001 | Live/paper data feed adapters | Could | 6+ | BT-DATA-001 | Same IDataSource port; replay unaffected |
| BT-FUT-002 | Broker bridge (live order routing) | Could | 7+ | BT-EXEC-001+ | Out of scope until sandbox+security model mature |
| BT-FUT-003 | ML feature export (tick→tensor pipelines) | Could | 6+ | BT-DATA-008 | Deterministic windowed export |
| BT-FUT-004 | Linux/macOS core support | Could | 6+ | BT-CORE-001 | Core already platform-neutral by design |
| BT-FUT-005 | Shared-memory IPC transport for strategies | Could | 5+ | BT-STRAT-003 | Wire-format-compatible ring transport |
| BT-FUT-006 | Depth-of-market replay + DOM strategies | Could | 5+ | BT-DATA-003 | Depth-driven fills behind ExecutionModel port |

## Traceability

- Feature-by-phase overview: FEATURE_MATRIX.md.
- Architecture rules behind these requirements: SYSTEM_ARCHITECTURE.md + ADRs.
- Definition of done for each phase: QUALITY_GATES.md.
