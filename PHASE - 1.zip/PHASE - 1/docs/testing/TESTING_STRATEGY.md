# BACKTEST — Testing Strategy

Status: Phase 0. Categories, ownership, and gates. Phase 0 ships **only** the minimum tests that validate the foundation (list at the end) — no token tests for unbuilt features.

## 1. Principles

1. Tests encode contracts: every rule in the architecture docs that can fail must have a test that fails when violated.
2. Tests run offline, fast (full suite < 30 s until Phase 4), no external services, no network.
3. Determinism tests are the product's core defense — they run on every push, not nightly.
4. No test mocks what it verifies: engines are tested against real (synthetic) data, not mocks of themselves.

## 2. Test categories

| Category | What it proves | Where it lives | Phase start |
|---|---|---|---|
| **Unit** | One type/logic correct in isolation | `tests/Backtest.Core.Tests` | 0 |
| **Architecture/contract** | Structural rules hold (layering, ordering, formats) | `tests/Backtest.Core.Tests` (+ dedicated arch test project if it grows) | 0 |
| **Determinism** | Same inputs ⇒ byte-identical traces; snapshot/branch equality | dedicated collection, non-parallel | 0 (seed/queue), 2 (full-run) |
| **Integration** | Two+ modules over real seams (store+kernel, kernel+runtime) | `tests/Backtest.Integration.Tests` | 1 |
| **Contract (Strategy API)** | Wire framing/handshake/error codes per language adapter | per-adapter test suites | 2 |
| **Serialization** | Formats round-trip; version negotiation; corruption rejected | core + store tests | 0 (trace/wire), 1 (store) |
| **Data integrity** | Validation rules catch every documented violation; CRC rejects corrupt segments | store tests | 1 |
| **Snapshot/restore** | Continue/branch equality to control runs; hash mismatch rejected | integration | 2 |
| **Regression** | Bug gets a failing test before fix; stays forever | wherever the bug lives | continuous |
| **Property-based** | Invariants over generated inputs (queue total-order, grid conformance, P&L additivity) | core tests (CsCheck or hand-rolled generators) | 2 |
| **Strategy API compatibility** | Old wire/API versions keep passing against new engine (rule 18) | golden frame corpus | 2 |
| **Performance** | Budget floors hold on CI hardware class; never absolute times | `tests/Performance.Tests` (run manually or labeled) | 2 |
| **UI** | View models headlessly; golden-image chart renders | `tests/Ui.Tests` | 3 |

## 3. What must never happen

- A test that cannot fail (asserts nothing, or asserts on mocks of the code under test).
- A skipped/ignored test without a linked issue and requirement ID.
- Flaky tests tolerated: a determinism/integration test that flakes is a defect — fixed or quarantined *with an issue*, never left red.

## 4. Phase 0 test inventory (shipped, all green)

`tests/Backtest.Core.Tests/ArchitectureValidationTests.cs` — 37 tests (plus CLI selftest smoke checks):

- **Money**: exactness, currency-mismatch rejection, currency validation, minor-unit rounding rules.
- **Quantity**: negativity rejection, step conformance, underflow rejection.
- **Price**: positivity, tick conformance with documented tie-breaking.
- **Time**: strict monotonicity, sub-sequence for equal timestamps, UTC normalization.
- **Events**: envelope validity, total order (time→rank→sequence), insertion-order independence.
- **Kernel**: cross-instance trace determinism, clock-advance discipline, deadline handling, stopped-state rejection, monotonic EventIds.
- **Wire**: frame round-trip, length-prefix coverage, truncation/corruption rejection, parameter escaping round-trip, malformed-input rejection.
- **Determinism**: SplitMix64 reference vector, reproducibility over 10k draws, unit-interval doubles.
- **Serialization**: canonical trace byte-freeze, culture-independence reasoning.

## 5. Gate wiring

- `dotnet test` runs in CI on every push/PR; failing tests block merge (QG-1).
- Phase gates add categories cumulatively — a phase may not disable a prior phase's tests (QG-6).
