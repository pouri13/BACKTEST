# Phase 0 Report — Architecture & Project Foundation

- Date: 2026-09-21
- Status: complete (all Phase 0 gates in docs/QUALITY_GATES.md pass)
- Verification: `dotnet build -c Release` zero warnings · `dotnet test -c Release` 37/37 green · `dotnet format --verify-no-changes` clean · `python scripts/verify_docs.py` OK

## 0. Binding development rules (all phases)

1. No MetaTrader dependency. 2. No MT4/MT5 dependency. 3. No Soft4FX dependency. 4. No TradingView dependency. 5. No copying proprietary code. 6. No proprietary assets without licensing. 7. Core is UI-independent. 8. Strategy API is language-agnostic. 9. Backtests are deterministic for identical config/data/seed. 10. No look-ahead bias. 11. Financial calculations use explicit precision rules. 12. Never silently remove requested functionality. 13. Never fake unfinished functionality. 14. Interfaces/contracts before implementation. 15. Keep modules loosely coupled. 16. Document major architectural decisions. 17. Write tests alongside implementation. 18. Backward compatibility for versioned APIs. 19. Market data is immutable source data. 20. Every completed feature has an acceptance test.

## 1. What was designed (specifications — the bulk of Phase 0)

- **Product requirements** — 15 categories, 100+ numbered requirements (BT-*) with priority/phase/dependencies/acceptance criteria.
- **Feature matrix** — every charting/trading/replay/backtesting/runtime/debugging/data/analytics/optimization feature mapped to phase, architectural owner, dependencies, test strategy.
- **System architecture** — layered UI → Application → Core → Infrastructure; the prime directive (core ⊁ UI) with enforcement mechanisms; module table with adjusted boundaries (Broker Simulator subsystem grouping, Portfolio deferred).
- **Event model** — envelope with identity/causality fields, fixed ordering ranks encoding causality, total order (time → rank → sequence), payload catalog, serialization strategy.
- **Time model** — five distinct clocks; UTC normalization; DST-safe session anchors; tick ordering; out-of-order/missing-data handling; structural look-ahead prevention.
- **Money model** — decimal-only financial arithmetic, four named rounding rules with conservatism principle, grid conformance, currency-bound values.
- **Domain model** — Instrument/Order/Fill/Position/Trade/Account + BrokerSimulator/ExecutionModel ports, order state machine, execution realism switches, fill guarantees.
- **Strategy API** — language-agnostic wire protocol (framing, handshake, lock-step dispatch, state export/import, error codes, versioning); adapters-not-embedding policy.
- **Strategy sandbox** — process isolation, Job Object resource limits, capability/permission model, kill/restart-from-snapshot semantics.
- **Snapshot system** — full-state content-addressed snapshots, all-or-nothing capture, continue + branch semantics, hash validation.
- **Data architecture** — format comparison (custom columnar vs Parquet/SQLite/MMF), immutable versioned datasets, validation pipeline, engine-facing IDataSource.
- **Performance architecture** — bottleneck analysis, budget model, sequential-core/parallel-runs policy, explicit non-optimization list.
- **UI architecture** — panel/data-contract table, state delivery model, chart rendering approach, zero domain logic law.
- **Security architecture** — trust model, hard boundaries, resource defense, supply chain rules.
- **Technology decisions** — TD-1..TD-10 with alternatives/pros/cons/reasons/consequences + rejection table.
- **ADRs 0001–0009** — architecture style, core/UI separation, strategy API, storage, event model, precision, IPC/isolation, snapshots, honest-status policy.
- **Testing strategy & quality gates** — 13 test categories, permanent + per-phase gates.

## 2. What was implemented (working code, all test-verified)

| Artifact | Location | Proven by |
|---|---|---|
| Money/Price/Quantity primitives, RoundingRule tables | `src/Backtest.Core/Primitives` | 15 tests (exactness, rejection, conformance, tie-breaks) |
| SimClock (monotonic, UTC, sub-sequence) | `src/Backtest.Core/Time` | 3 tests |
| SeededRandom (SplitMix64, reference-vector pinned) | `src/Backtest.Core/Determinism` | 3 tests |
| EventEnvelope/EventKind/EventQueue (total order) | `src/Backtest.Core/Events` | 5 tests |
| SimulationKernel (deterministic loop, deadline, trace) + canonical trace | `src/Backtest.Core/Engine` | 5 tests |
| WireCodec + WireParams (Strategy API v1 framing) | `src/Backtest.Core/Wire` | 7 tests |
| Strategy ports (IStrategyContext/Runtime, descriptor) | `src/Backtest.Core/Ports` | compile-time contract |
| Headless CLI (`demo`, `selftest`) | `src/Backtest.Cli` | run in verification |
| Architecture test suite (37 tests) | `tests/Backtest.Core.Tests` | CI |
| CI pipeline (build → format → test, Windows) | `.github/workflows/ci.yml` | first push |
| Docs-consistency script | `scripts/verify_docs.py` | run in verification |

## 3. What was deliberately NOT implemented (per the brief)

- Backtesting/execution engines (Phase 2) — the kernel processes and traces events only; it computes no orders, fills, positions, or P&L.
- Market-data pipeline, store, importers, calendars (Phase 1).
- Broker simulator incl. SL/TP/trailing/OCO/margin/swap (Phase 2).
- Strategy runtimes for any language; sandbox host (Phases 2–4; the wire codec and ports exist).
- Snapshot capture/restore (Phase 2; the kernel state machine it needs exists).
- Charting, UI shell, replay transport (Phase 3).
- Analytics, reports, optimization, plugins, packaging (Phases 4–5).

No stubs, mock engines, or placeholder return values were created anywhere (ADR-0009).

## 4. Architecture decisions (summary — full records in ADRs/TDs)

Event-driven modular monolith with single-threaded deterministic kernel (ADR-0001); core ⊁ UI enforced (ADR-0002); wire-protocol Strategy API with adapters, no embedding (ADR-0003); SQLite catalog + custom columnar store (ADR-0004); single ordered queue with fixed causality ranks (ADR-0005); decimal-only money with named rounding (ADR-0006); process-isolated strategies over stdio/pipes (ADR-0007); full-state content-addressed snapshots (ADR-0008); no-fake-implementations policy (ADR-0009).

## 5. Known limitations

- Kernel payload processing is intentionally a no-op recorder in Phase 0 — the trace is the contract; engines subscribe in Phase 1+.
- The wire protocol is implemented and tested in-process only; no transport (stdio/pipe) loop exists until the runtime work in Phase 2.
- Ranks/queue are heap-based; same-timestamp batches are fine at Phase 0 scale but Phase 2 may switch to array-based tiers for hot-path throughput (ordering contract unchanged).
- No `Directory.Packages.props` yet — deliberately deferred until the first NuGet dependency (TD-10).
- Only canonical NDJSON serialization of envelope headers is frozen; payload serialization freezes with the store in Phase 1.

## 6. Risks

- .NET per-core throughput ceiling for billion-event replay — mitigated by the columnar store design and the native-plugin escape hatch behind ports (TD-1); decided against C++ for Phase 1–3 velocity.
- Owning a custom wire + data format is a maintenance liability — mitigated by freeze tests, version fields, and the docs-consistency script.
- GC pressure in sustained replay — Phase 1–2 must budget allocations (pooled envelopes, batched trace writes) or the Phase 2 perf floors (≥5M/s) are at risk.
- Strategy API v1 freeze at Phase 2 GA is a one-way door — handshake/versioning machinery exists; the freeze checklist is part of the Phase 2 gate.
- Windows Job Objects bind the sandbox to Windows — accepted (Windows-only product); cgroups port documented for the future.

## 7. Open questions

1. Venue adapters for historical downloads (Phase 2): which providers are in-scope first, and their licensing/terms?
2. Instrument metadata model depth for Phase 2: per-venue fee/swap modeling granularity.
3. Whether Phase 3 chart virtualization targets SkiaSharp compositions directly or an intermediate scene graph (decide with a perf spike early in Phase 3).

## 8. Technical debt (tracked, deliberate)

- `IsoMinorUnits` currency table is a hardcoded subset (JPY/KRW/…, BHD/…); full ISO-4217 table with Phase 1 config.
- `WireParams` line-based encoding is fine for params but not for bulk payloads; the binary payload schema design (Phase 2) will supersede it for event frames.
- CLI arg parsing is hand-rolled; replace when commands multiply (Phase 1) with a parsing library or structured subcommands.
- Event-source enum and payload catalog will need namespace reorganization as engines land (keep `Backtest.Core.Events` from bloating).

## 9. Phase 1 prerequisites

- [x] Deterministic kernel + trace format frozen
- [x] Store format decision recorded (ADR-0004) — spec document is the first Phase 1 deliverable
- [x] Config/provenance requirements numbered (BT-CORE-007/008) and gated
- [ ] Venue sample data for validation fixtures (user-provided or synthetic generator — decide at Phase 1 start)
- [ ] `Directory.Packages.props` when the first NuGet package (e.g. SQLite) lands

## 10. Build & test instructions

```bash
# Build (requires .NET 8 SDK, pinned in global.json)
dotnet build -c Release          # zero warnings expected (warnings-as-errors)

# Test
dotnet test -c Release           # 37/37 green expected

# Format check
dotnet format --verify-no-changes

# Docs consistency
python scripts/verify_docs.py

# Headless demo
dotnet run --project src/Backtest.Cli -c Release -- demo
dotnet run --project src/Backtest.Cli -c Release -- selftest
```

CI (GitHub Actions, Windows runner) runs restore → build → format check → tests on every push/PR.
