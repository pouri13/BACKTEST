# BACKTEST — Quality Gates

Status: Phase 0. Objective, checkable criteria. A phase is complete only when every gate below holds **and** the phase's own gate table (in its report) holds. Gates are cumulative — later phases inherit earlier ones.

## Permanent gates (every phase, every PR)

| ID | Gate | Verification |
|---|---|---|
| QG-1 | Build succeeds with zero warnings; all tests pass | `dotnet build -c Release` + `dotnet test -c Release` in CI; warnings-as-errors is on |
| QG-2 | Architecture contracts unbroken: Core has no UI/OS deps; dependencies point downward only; no Core project references UI assemblies | architecture tests + CI project-reference audit (from Phase 1) |
| QG-3 | Format/serialization changes are versioned: changing a frozen format requires a new version + migration path + updated freeze tests | contract tests + review checklist |
| QG-4 | Documentation current: every new module documented in SYSTEM_ARCHITECTURE §3 table; every major decision has an ADR; phase report updated | verify-docs script + review |
| QG-5 | Determinism preserved: full-run determinism tests pass; any change that breaks byte-identical replay is rejected or gated behind an explicit, versioned config change | determinism test suite |
| QG-6 | No silent removal or fake implementation: features marked implemented have acceptance tests; removed features are marked in requirements with rationale; no stubs presented as done (ADR-0009) | phase-report audit + test-to-feature spot checks |
| QG-7 | No TODO-as-feature: compiled sources contain no bare TODO/FIXME markers; TODOs must reference a requirement ID | grep in CI (from Phase 1) |
| QG-8 | Regression tests never deleted or weakened to make a suite pass | review + test-count trend check in CI |

## Phase completion criteria (per phase, on top of permanent gates)

### Phase 0 — Foundation (this phase)

- [x] Repository structure per §16 of the brief; builds and tests pass locally
- [x] Product requirements, feature matrix, architecture docs, ADRs 0001–0009
- [x] Determinism/ordering/precision/wire contracts pinned by tests (37 tests)
- [x] CI pipeline real and green (build + format check + tests, Windows runner)
- [x] Phase report lists implemented / designed / deliberately-not-implemented

### Phase 1 — Data pipeline

- Store format spec frozen + round-trip + corruption-rejection tests green
- CSV/JSON import validated end-to-end on ≥2 venue samples; validation rules each have a violation fixture
- Catalog + provenance live: run manifests record config hash, dataset versions, engine version
- Config load/validate with hard failure (BT-CORE-007/008, BT-REL-004)

### Phase 2 — Engine

- Order/execution/position/account engine with scenario tests per BT-EXEC-001..020
- C# strategy runtime + contract tests (BT-STRAT-002)
- Snapshot save/restore/continue + branch equality tests (ADR-0008)
- Performance floors measured: ≥5M events/s bare, ≥1M with in-process strategy (CI hardware class)
- Determinism: full-run byte-identical across machines; snapshot equality proven

### Phase 3 — Replay & UI

- Replay transport (play/pause/step/seek/speed) driven by kernel state machine; snapshot-based seek
- Sandbox host with Job Object limits; crash-injection + limit-breach tests green
- Avalonia shell with docking; chart panel ≥60 fps target on 100k bars; all panels event-driven, no domain logic

### Phase 4 — Analytics & multi-language

- Analytics suite with reference-value tests; CSV/JSON/Excel/HTML reports
- Python runtime behind sandbox passing the full contract suite
- Portfolio backtesting across symbols

### Phase 5 — Optimization & packaging

- Optimizers deterministic under parallelism (worker-count invariance tests)
- Plugin system with capability model; sample plugins pass permission tests
- MSIX packaging signed; auto-update path proven

## Violations that block a phase regardless of other criteria

- Required tests failing or skipped without linked issue
- Architecture contracts broken (QG-2) — including "temporary" waivers
- Documentation missing for a shipped module or decision
- Features silently removed, stubs presented as complete, fake data shown as results
- Build broken on the pinned SDK
- Any regression test failing
